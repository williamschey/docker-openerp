from django.contrib.admin.util import unquote
from django import forms

from pbs.admin import BaseAdmin
from pbs.prescription.admin import (
    PrescriptionMixin, SavePrescriptionMixin)
from pbs.prescription.forms import PrescriptionIgnitionCompletedForm
from pbs.report.forms import AreaAchievementForm

from chosen.widgets import ChosenSelectMultiple


class AreaAchievementAdmin(PrescriptionMixin, SavePrescriptionMixin,
                           BaseAdmin):
    list_display = (
        "ignition", "ignition_types", "area_treated", "area_estimate",
        "edging_length", "edging_depth_estimate",
        "date_escaped", "dpaw_fire_no", "dfes_fire_no")
    list_editable = (
        "ignition", "ignition_types", "area_treated", "area_estimate",
        "edging_length", "edging_depth_estimate",
        "date_escaped", "dpaw_fire_no", "dfes_fire_no")
    list_display_links = (None,)
    list_empty_form = True
    actions = None
    form = AreaAchievementForm

    def formfield_for_manytomany(self, db_field, request=None, **kwargs):
        kwargs['widget'] = ChosenSelectMultiple()
        return super(AreaAchievementAdmin, self).formfield_for_manytomany(
            db_field, request, **kwargs)

    def get_readonly_fields(self, request, obj=None):
        """
        Allow adding achievements post approval but not post closure.
        """
        current = self.prescription
        if current.is_closed or not current.is_approved:
            return self.list_editable
        else:
            return (None,)

    def get_changelist_form(self, request, **kwargs):
        if kwargs.get('form') is not None:
            class AAForm(kwargs.get('form'), self.form):
                pass
            form = AAForm
        else:
            form = self.form
        return form

    def get_changelist_formset(self, request, **kwargs):
        FormSet = super(AreaAchievementAdmin,
                        self).get_changelist_formset(request, **kwargs)
        prescription = self.prescription
        editable = self.editable
        model_admin = self

        class PICForm(PrescriptionIgnitionCompletedForm):
            def __init__(self, *args, **kwargs):
                self.model_admin = model_admin
                self.request = request
                super(PICForm, self).__init__(*args, **kwargs)

            def has_changed(self):
                """
                This intentionally returns False so that the
                admin.changelist_view() does not mess up with it the .save() is
                performed here, I know, weird but there are not many places in
                the .changelist_view() to hook this additional logic to.
                admin.changelist_view() skips this because it thinks it does
                not change otherwise the changed form counting is messed up
                (if nothing else).
                """
                if super(PICForm, self).has_changed() and editable:
                    self.save()
                    self.model_admin.message_user(
                        self.request, "Saved ignition completed date")
                return False

        # we are patching the formset here to include an extra form
        # note: this form must be popped before it is processed by the
        # result_list (result_list needs a set of forms of the same type)
        class AreaAchievementFormSet(FormSet):
            def _construct_forms(self):
                super(AreaAchievementFormSet, self)._construct_forms()
                self.forms.append(PICForm(request.POST or None,
                                          instance=prescription))

            def full_clean(self):
                super(AreaAchievementFormSet, self).full_clean()
                if self.is_bound:
                    special_form = self.forms[self.total_form_count()]
                    self._errors.append(special_form.errors)

            @property
            def extra_forms(self):
                # we ignore our "special" form, if the formset validation fails
                # the failed unsaved form instances are extra forms so we
                # cannot do something like
                # [:self.initial_form_count() + self.extra]
                return self.forms[self.initial_form_count():-1]

            @property
            def media(self):
                # super.media won't work properly if there are not forms in the
                # formset (the only form then is PICForm so its media are taken
                # instead of the empty_form's media)
                media = (len(self.forms) > 1 and self.forms[0].media or
                         self.empty_form.media)
                return media + self.forms[-1].media     # + our "special" form

            def _field_validation_error(self, msg, form, name):
                e = forms.ValidationError(msg)
                form._errors[name] = form.error_class(e.messages)
                if name in form.cleaned_data:
                    del form.cleaned_data[name]

            def is_valid(self):
                # run .is_valid() for our "special" last form
                forms_valid = super(AreaAchievementFormSet, self).is_valid()
                forms_valid &= self.forms[self.total_form_count()].is_valid()
                if forms_valid:
                    # perform some extra validation for the entire formset
                    # this should probably go to .clean() but that does not get
                    # called from admin.changelist_view()

                    last_ignition_date = None
                    for i in range(0, self.total_form_count()):
                        form = self.forms[i]
                        ignition_date = form.cleaned_data.get('ignition')

                        if (ignition_date is not None and
                                (last_ignition_date is None or
                                 ignition_date > last_ignition_date)):
                            last_ignition_date = ignition_date

                    special_form = self.forms[self.total_form_count()]
                    ignition_completed_date = special_form.cleaned_data[
                        'ignition_completed_date']

                    # make sure the ignition_completed_date is not before any
                    # of the burn ignition_date(s)
                    if (last_ignition_date is not None and
                            ignition_completed_date is not None and
                            ignition_completed_date < last_ignition_date):
                        forms_valid = False
                        self._field_validation_error(
                            "Ignition completed date must be later than " +
                            "the most recent area achievement date.",
                            special_form, 'ignition_completed_date')

                    # make sure there is at least one achievement if the
                    # ignition_completed_date is set
                    if (ignition_completed_date and
                            self.total_form_count() == 0):
                        forms_valid = False
                        self._field_validation_error(
                            "You must enter at least one achievement before " +
                            "you can set an ignition completed date.",
                            special_form, 'ignition_completed_date')

                return forms_valid

        return AreaAchievementFormSet

    def changelist_view(self, request, prescription_id, extra_context=None):
        current = self.get_prescription(request, unquote(prescription_id))
        self.editable = current.is_approved

        # damn, this form comes after the entire formset in the template
        # so we cannot use the
        # trick with popping the last form first (like with
        # priorityJustification), it is not rendered in the same block
        """
        form = PrescriptionIgnitionCompletedForm(request.POST or None,
                                                 instance=current)
        if request.method == "POST" and editable:
            if form.is_valid() and form.has_changed():
                form.save()

        """
        context = {
            'editable': self.editable,
        }
        context.update(extra_context or {})

        return super(AreaAchievementAdmin, self).changelist_view(
            request, prescription_id, extra_context=context)


class ProposedActionAdmin(PrescriptionMixin, SavePrescriptionMixin,
                          BaseAdmin):
    list_display = ('observations', 'action')
    list_editable = ('observations', 'action')
    list_empty_form = True
    list_display_links = (None, )
    actions = None

    def get_readonly_fields(self, request, obj=None):
        """
        Allow adding achievements post approval but not post closure.
        """
        current = self.prescription
        if ((current and (current.status == current.STATUS_CLOSED
             or current.approval_status != current.APPROVAL_APPROVED))):
            return self.list_editable
        else:
            return (None,)


class EvaluationAdmin(PrescriptionMixin, SavePrescriptionMixin,
                      BaseAdmin):
    prescription_filter_field = "criteria__prescription"
    list_display = ('criteria', 'achieved', 'summary')
    list_editable = ('achieved', 'summary')
    list_display_links = (None,)
    actions = None

    def queryset(self, request):
        qs = super(EvaluationAdmin, self).queryset(request)
        # django 1.5's list_select_related is not smart enough to understand a
        # tuple
        return qs.select_related("criteria__prescription", "criteria")

    def objectives(self, obj):
        objectives = "<ul>"
        for objective in obj.criteria.objectives.all():
            objectives += "<li>%s</li>" % objective
        objectives += "</ul>"
        return objectives
    objectives.short_description = "Burn objectives"
    objectives.allow_tags = True

    def get_readonly_fields(self, request, obj=None):
        """
        Allow adding achievements post approval but not post closure.
        """
        current = self.prescription
        if current.is_closed or not current.is_approved:
            return self.list_editable
        else:
            return (None,)


class PostBurnChecklistAdmin(PrescriptionMixin, SavePrescriptionMixin,
                             BaseAdmin):
    list_display = ('action', 'relevant', 'completed_on', 'completed_by')
    list_editable = ('relevant', 'completed_on', 'completed_by')
    list_display_links = (None,)
    actions = None

    def get_readonly_fields(self, request, obj=None):
        """
        Allow adding achievements post approval but not post closure.
        """
        current = self.prescription
        if ((current and (current.status == current.STATUS_CLOSED
             or current.approval_status != current.APPROVAL_APPROVED))):
            return self.list_editable
        else:
            return (None,)
