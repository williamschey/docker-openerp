from django.conf.urls.defaults import patterns, include, url
from django.conf import settings
from django.views.generic import TemplateView

from pbs.sites import site
from pbs.forms import PbsPasswordResetForm

urlpatterns = patterns(
    '',
    (r'^docs/', include('django.contrib.admindocs.urls')),
    url(r'^select2/', include('django_select2.urls')),
    (r'^', include('pbs.registration.urls')),
    # the password reset must come before site.urls, site.urls match all  r'^[^/]+/$'
    url(r'^password_reset/$', 'django.contrib.auth.views.password_reset',
        {'password_reset_form': PbsPasswordResetForm}, name='password_reset'),
    (r'^', include(site.urls)),
    (r'^', include('django.contrib.auth.urls')),
    url(r'^chaining/', include('smart_selects.urls')),
    (r'^media/(?P<path>.*)$', 'django.views.static.serve',
     {'document_root': settings.MEDIA_ROOT}),
)
