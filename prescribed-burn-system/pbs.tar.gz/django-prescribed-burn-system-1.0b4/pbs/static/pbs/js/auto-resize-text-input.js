function resizeInput() {
    $(this).attr('size', $(this).val().length+0.7);
}    
