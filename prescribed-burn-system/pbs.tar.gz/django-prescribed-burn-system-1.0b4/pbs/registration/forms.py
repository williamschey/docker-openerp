
from django import forms
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from django.utils.safestring import mark_safe
from django.templatetags.static import static

from registration.forms import (RegistrationFormUniqueEmail,
                                RegistrationFormTermsOfService)

from pbs.forms import PbsErrorList


class PbsRegistrationForm(RegistrationFormTermsOfService,
                          RegistrationFormUniqueEmail):
    def __init__(self, *args, **kwargs):
        kwargs['error_class'] = PbsErrorList
        super(PbsRegistrationForm, self).__init__(*args, **kwargs)
        terms_of_service_url = static('pbs/docs/terms_of_service.doc')
        self.fields['tos'].label = mark_safe(
            'I have read and agree to the ' +
            '<a href="{0}" title="Terms of Service">Terms of Service</a>'
            .format(terms_of_service_url)
        )

    def clean_email(self):
        email = self.cleaned_data['email']
        if not email.lower().endswith(settings.FPC_EMAIL_EXT):
            raise forms.ValidationError(
                _("This is not a valid FPC email address."))
        return super(PbsRegistrationForm, self).clean_email()
