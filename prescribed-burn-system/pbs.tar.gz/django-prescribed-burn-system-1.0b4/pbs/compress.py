from compressor.js import JsCompressor as DefaultJsCompressor
from compressor.css import CssCompressor as DefaultCssCompressor
from compressor.parser.lxml import LxmlParser
from compressor.base import Compressor

#
# settings.py
#
# COMPRESS_JS_COMPRESSOR = '.compress.JsCssCompressor'
# COMPRESS_PARSER = '.compress.CompressParser'
#
# base.html
#
# <!doctype html>
# <html>
# <head>
#    {% compress js %}
#    ...
#    {% endcompress %}
# </head>
# </html>


class CompressorMixin(Compressor):
    def split_contents(self):
        _split_contents = super(CompressorMixin, self).split_contents()
        for kind, value, basename, elem in _split_contents:
            self.parser.elem_remove(elem)
        return _split_contents


class JsCompressor(CompressorMixin, DefaultJsCompressor):
    pass


class CssCompressor(CompressorMixin, DefaultCssCompressor):
    pass


class JsCssCompressor(object):
    def __init__(self, *args, **kwargs):
        self.args = args
        self.kwargs = kwargs

    def output(self, mode='file', forced=False):
        css_compressor = CssCompressor(*self.args, **self.kwargs)
        css_output = css_compressor.output(mode, forced)
        self.kwargs.update({
            'content': css_compressor.parser.get_processed_content()})
        js_compressor = JsCompressor(*self.args, **self.kwargs)
        js_output = js_compressor.output(mode, forced)
        return (css_output + js_output +
                js_compressor.parser.get_processed_content())


class CompressParser(LxmlParser):
    def js_elems(self):
        return self.tree.xpath("//script[not(@data-compress='false')]")

    def css_elems(self):
        return self.tree.xpath(
            '//link[re:test(@rel, "^stylesheet$", "i")]'
            '[not(@data-compress="false")]|style[not(@data-compress="false")]',
            namespaces={"re": "http://exslt.org/regular-expressions"})

    def get_processed_content(self):
        # remove <root> and </root>
        return self.tostring(self.tree, method='html')[6:-7]

    def elem_remove(self, elem):
        elem.getparent().remove(elem)
