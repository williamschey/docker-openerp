from django import template
from django.db.models import Max
from django.utils.safestring import mark_safe
from django.template.defaultfilters import stringfilter

from pbs.implementation.models import (Way, RoadSegment, TrailSegment,
                                       SignInspection, TrafficControlDiagram)
from pbs.risk.models import Action, Register

register = template.Library()


@register.simple_tag
def risk_display(register, draft=False):
    """
    Display as HTML span.
    """
    if draft:
        level = register.draft_risk_level
        name = register.get_draft_risk_level_display()
        id_ = "id_max_draft_risk_" + str(register.id)
    else:
        level = register.final_risk_level
        name = register.get_final_risk_level_display()
        id_ = "id_max_final_risk_" + str(register.id)

    if level == Register.LEVEL_VERY_LOW:
        label = 'label-very-low'
    elif level == Register.LEVEL_LOW:
        label = 'label-low'
    elif level == Register.LEVEL_MEDIUM:
        label = 'label-medium'
    elif level == Register.LEVEL_HIGH:
        label = 'label-high'
    else:
        label = 'label-very-high'

    return mark_safe(
        '<span id="%s" class="label %s">%s</span>' % (id_, label, name))


@register.simple_tag(takes_context=True)
def pfp_status(context):
    """
    Renders the PDF output's header line.
    """
    current = context['prescription']
    return "{0}, {1}, {2}, {3}, {4}".format(
        current.get_planning_status_display(),
        current.get_endorsement_status_display(),
        current.get_approval_status_display(),
        current.get_ignition_status_display(),
        current.get_status_display()
    )


@register.assignment_tag(takes_context=True)
def all_actions(context):
    """
    All actions on the current prescription.
    """
    current = context['current']
    qs = Action.objects.filter(risk__prescription=current, relevant=True)
    qs.modified = qs.aggregate(Max('modified'))["modified_max"]
    pre_burn = qs.filter(pre_burn=True)
    pre_burn.modified = pre_burn.aggregate(Max('modified'))["modified_max"]
    day_burn = qs.filter(day_of_burn=True)
    day_burn.modified = day_burn.aggregate(Max('modified'))["modified_max"]
    post_burn = qs.filter(post_burn=True)
    post_burn.modified = post_burn.aggregate(Max('modified'))["modified_max"]

    return {
        "pre_burn": pre_burn,
        "day_of_burn": day_burn,
        "post_burn": post_burn,
        "all": qs,
    }


@register.assignment_tag(takes_context=True)
def all_ways(context):
    """
    All of the roads, tracks, and trails for a particular ePFP.
    """
    current = context['current']

    roads = RoadSegment.objects.filter(prescription=current)
    trails = TrailSegment.objects.filter(prescription=current)
    ways = Way.objects.filter(prescription=current)
    inspections = SignInspection.objects.filter(way__prescription=current)
    traffic_diagrams = TrafficControlDiagram.objects.filter(
        roadsegment__prescription=current).exclude(name="custom").distinct()

    for qs in [roads, trails, ways, inspections]:
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]

    return {
        "roads": roads,
        "trails": trails,
        "ways": ways,
        "standard_traffic_diagrams": traffic_diagrams,
        "inspections": inspections,
        "modified": max([modified for modified in
                         roads.modified, trails.modified,
                         ways.modified, inspections.modified,
                         current.created
                         if modified is not None])
    }


@register.filter
@stringfilter
def latex_criteria(value):
    """
    Priority justification criteria in A4 latex PDF
    """
    value = value.replace('    ', '\hspace*{0.5cm}').replace('\n', '\\newline')
    return value


@register.assignment_tag
def get_required_role(prescription):
    risk, label, role = prescription._max_risk(prescription.maximum_risk)
    return role
