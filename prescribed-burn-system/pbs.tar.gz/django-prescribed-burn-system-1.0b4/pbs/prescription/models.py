from __future__ import (division, print_function, unicode_literals,
                        absolute_import)
import logging
logger = logging.getLogger("log." + __name__)

from datetime import timedelta
from dateutil import tz
from decimal import Decimal
from collections import OrderedDict

from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db.models import Q, Max, Sum
from django.db.models.signals import post_save, m2m_changed
from django.dispatch import receiver
from django.forms import ValidationError
from django.template.defaultfilters import truncatewords
from django.utils.encoding import python_2_unicode_compatible
from django.utils.safestring import mark_safe
from django.utils import timezone

from swingers import models
from swingers.models import Audit
from smart_selects.db_fields import ChainedForeignKey

from pbs.risk.models import (
    Register, Risk, Action, Complexity, Context, Treatment)


@python_2_unicode_compatible
class Season(Audit):
    SEASON_SPRING = 1
    SEASON_SUMMER = 2
    SEASON_AUTUMN = 3
    SEASON_WINTER = 4
    SEASON_EARLY_DRY = 5
    SEASON_LATE_DRY = 6
    SEASON_WET = 7
    SEASON_CHOICES = (
        (SEASON_SUMMER, "Summer"),
        (SEASON_AUTUMN, "Autumn"),
        (SEASON_WINTER, "Winter"),
        (SEASON_SPRING, "Spring"),
        (SEASON_EARLY_DRY, "Early Dry"),
        (SEASON_LATE_DRY, "Late Dry"),
        (SEASON_WET, "Wet"),
    )

    name = models.PositiveSmallIntegerField(
        choices=SEASON_CHOICES, default=SEASON_AUTUMN)
    start = models.DateField(help_text="Start date of season")
    end = models.DateField(help_text="End date of season")

    def __str__(self):
        if self.start.year == self.end.year:
            year = self.start.year
        else:
            year = "%s/%s" % (self.start.year, self.end.year)
        return "%s %s" % (self.get_name_display(), year)

    class Meta:
        ordering = ["-start"]


class RegionManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


@python_2_unicode_compatible
class Region(models.Model):
    """
    """
    name = models.CharField(max_length=64, unique=True)
    objects = RegionManager()

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name,)


class DistrictManager(models.Manager):
    def get_by_natural_key(self, region, name):
        region = Region.objects.get_by_natural_key(region)
        return self.get(name=name, region=region)


@python_2_unicode_compatible
class District(models.Model):
    region = models.ForeignKey(Region)
    name = models.CharField(max_length=200, unique=True)
    code = models.CharField(max_length=3)
    objects = DistrictManager()

    def __str__(self):
        return self.name

    def natural_key(self):
        return self.region.natural_key() + (self.name,)
    natural_key.dependencies = ['prescription.region']

    class Meta:
        ordering = ['name']


class ShireManager(models.Manager):
    def get_by_natural_key(self, region, district, name):
        district = District.objects.get_by_natural_key(region, district)
        return self.get(name=name, district=district)


@python_2_unicode_compatible
class Shire(models.Model):
    district = models.ForeignKey(District)
    name = models.CharField(max_length=200)
    objects = ShireManager()

    def __str__(self):
        return "{0} ({1})".format(self.name, self.district)

    def natural_key(self):
        return self.district.natural_key() + (self.name,)
    natural_key.dependencies = ['prescription.district']

    class Meta:
        ordering = ['name']
        unique_together = ('name', 'district')


@python_2_unicode_compatible
class VegetationType(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class Tenure(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class Purpose(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


@python_2_unicode_compatible
class ForecastArea(models.Model):
    districts = models.ManyToManyField(District)
    name = models.CharField(max_length=200)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class EndorsingRoleManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


@python_2_unicode_compatible
class EndorsingRole(models.Model):
    name = models.CharField(max_length=320)
    disclaimer = models.TextField()
    objects = EndorsingRoleManager()

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name,)

    class Meta:
        ordering = ['name']


@python_2_unicode_compatible
class Prescription(Audit):
    """
    A Prescription is the core object in the system. It should contain all the
    top level attributes imported from Prescription Program Planning except
    Purposes and Objectives.
    """
    PRIORITY_UNSET = 0
    PRIORITY_NOT_APPLICABLE = 4
    PRIORITY_LOW = 1
    PRIORITY_MEDIUM = 2
    PRIORITY_HIGH = 3

    PRIORITY_CHOICES = (
        (PRIORITY_UNSET, 'Unset'),
        (PRIORITY_LOW, '1'),
        (PRIORITY_MEDIUM, '2'),
        (PRIORITY_HIGH, '3')
    )

    SENSING_PRIORITY_CHOICES = (
        (PRIORITY_HIGH, 'High'),
        (PRIORITY_MEDIUM, 'Medium'),
        (PRIORITY_LOW, 'Low'),
        (PRIORITY_NOT_APPLICABLE, 'Not Applicable'),
    )

    ALLOCATION_CHOICES = (
        (4, '04 - Recoupable projects'),
        (24, '24 - Nature conservation'),
        (32, '32 - Parks & Visitor Services'),
        (41, '41 - Sustainable Forest Management'),
        (42, '42 - Native forest'),
        (43, '43 - Plantations'),
    )

    PLANNING_DRAFT = 1
    PLANNING_SUBMITTED = 2
    PLANNING_APPROVED = 3
    PLANNING_CHOICES = (
        (PLANNING_DRAFT, 'Draft CBAS'),
        (PLANNING_SUBMITTED, 'Seeking corporate approval'),
        (PLANNING_APPROVED, 'CBAS Approved'),
    )

    ENDORSEMENT_DRAFT = 1
    ENDORSEMENT_SUBMITTED = 2
    ENDORSEMENT_APPROVED = 3
    ENDORSEMENT_CHOICES = (
        (ENDORSEMENT_DRAFT, 'Not Endorsed'),
        (ENDORSEMENT_SUBMITTED, 'Seeking endorsement'),
        (ENDORSEMENT_APPROVED, 'Endorsed'),
    )

    APPROVAL_DRAFT = 1
    APPROVAL_SUBMITTED = 2
    APPROVAL_APPROVED = 3
    APPROVAL_CHOICES = (
        (APPROVAL_DRAFT, 'Not Approved'),
        (APPROVAL_SUBMITTED, 'Seeking approval'),
        (APPROVAL_APPROVED, 'Approved'),
    )

    IGNITION_NOT_STARTED = 1
    IGNITION_COMMENCED = 2
    IGNITION_COMPLETE = 3
    IGNITION_STATUS_CHOICES = (
        (IGNITION_NOT_STARTED, 'No Ignitions'),
        (IGNITION_COMMENCED, 'Ignition Commenced'),
        (IGNITION_COMPLETE, 'Ignition Completed'),
    )

    STATUS_OPEN = 1
    STATUS_CLOSED = 2
    STATUS_CHOICES = (
        (STATUS_OPEN, 'Burn open'),
        (STATUS_CLOSED, 'Burn closed'),
    )

    YES_NO_NULL_CHOICES = (
        (None, '-----'),
        (False, 'No'),
        (True, 'Yes'),
    )

    INT_CHOICES = [(i, i) for i in range(1, 100)]

    burn_id = models.CharField(max_length=7, verbose_name="Burn ID")
    name = models.CharField(max_length=128)
    region = models.ForeignKey(Region)
    district = ChainedForeignKey(
        District, chained_field="region", chained_model_field="region",
        show_all=False, auto_choose=True, blank=True, null=True)
    shires = models.ManyToManyField(Shire, blank=True, null=True)
    planned_year = models.PositiveIntegerField(
        verbose_name="Planned Year", max_length=4)
    planned_season = models.PositiveSmallIntegerField(
        verbose_name="Planned Season", max_length=64,
        choices=Season.SEASON_CHOICES)
    last_year = models.PositiveIntegerField(
        verbose_name="Year Last Burnt", max_length=4, blank=True, null=True)
    last_season = models.PositiveSmallIntegerField(
        max_length=64, choices=Season.SEASON_CHOICES,
        verbose_name="Season Last Burnt", blank=True, null=True)
    last_season_unknown = models.BooleanField(
        default=False, verbose_name="Last Season Unknown?")
    last_year_unknown = models.BooleanField(
        default=False, verbose_name="Last Year Unknown?")
    contentious = models.NullBooleanField(
        choices=YES_NO_NULL_CHOICES,
        default=None, help_text="Is this burn contentious?")
    contentious_rationale = models.TextField(
        help_text="If this burn is contentious, a short explanation of why",
        verbose_name="Rationale", null=True, blank=True)
    aircraft_burn = models.BooleanField(
        verbose_name="Aircraft Burn?", default=False,
        help_text="Does this burn involve aerial ignition?")
    allocation = models.PositiveSmallIntegerField(
        max_length=64, choices=ALLOCATION_CHOICES,
        verbose_name="Program Allocation", blank=True, null=True,
        help_text="Program code which is assigned to the burn")
    priority = models.PositiveSmallIntegerField(
        verbose_name="Overall Priority", help_text="Priority for this burn",
        choices=PRIORITY_CHOICES, default=PRIORITY_UNSET)
    rationale = models.TextField(
        verbose_name="Overall Rationale", blank=True, null=True)
    remote_sensing_priority = models.PositiveSmallIntegerField(
        choices=SENSING_PRIORITY_CHOICES, default=PRIORITY_NOT_APPLICABLE,
        verbose_name=mark_safe("Remote Sensing Priority"),
        help_text=("Remote sensing priority"))
    treatment_percentage = models.PositiveSmallIntegerField(
        validators=[MaxValueValidator(100)], blank=True, null=True,
        help_text="Percentage of the planned area that will be treated (%)")
    location = models.CharField(
        help_text="Example: Nollajup Nature Reserve - 8.5 KM S of Boyup Brook",
        max_length="320", blank=True, null=True)
    area = models.DecimalField(
        verbose_name="Planned Burn Area", max_digits=12, decimal_places=1,
        help_text="Planned burn area (in ha)",
        validators=[MinValueValidator(0)], default=0.0)
    perimeter = models.DecimalField(
        max_digits=12, decimal_places=1,
        help_text="Planned burn perimeter (in km)",
        validators=[MinValueValidator(0)], default=0.0)
    regional_objectives = models.ManyToManyField(
        'RegionalObjective', help_text="Regional Objectives",
        verbose_name="Regional Objectives", null=True, blank=True)
    vegetation_types = models.ManyToManyField(
        VegetationType, verbose_name="Vegetation Types", null=True, blank=True)
    tenures = models.ManyToManyField(Tenure, blank=True)
    bushfire_act_zone = models.TextField(
        verbose_name="Bushfires Act Zone", blank=True, null=True)
    prohibited_period = models.TextField(
        verbose_name="Prohibited Period", blank=True, null=True)
    forecast_areas = models.ManyToManyField(
        ForecastArea, verbose_name="Forecast Areas", null=True, blank=True)
    prescribing_officer = models.ForeignKey(
        User, verbose_name="Prescribing Officer", blank=True, null=True)
    short_code = models.TextField(
        verbose_name="Short Code", blank=True, null=True)
    purposes = models.ManyToManyField(Purpose)
    planning_status = models.PositiveSmallIntegerField(
        verbose_name="Planning Status", choices=PLANNING_CHOICES,
        default=PLANNING_DRAFT)
    planning_status_modified = models.DateTimeField(
        verbose_name="Planning Status Modified", editable=False, null=True)
    endorsing_roles = models.ManyToManyField(
        EndorsingRole, verbose_name="Endorsing Roles")
    endorsing_roles_determined = models.BooleanField(
        verbose_name="Required Endorsing Roles", default=False)
    endorsement_status = models.PositiveSmallIntegerField(
        verbose_name="Endorsement Status", choices=ENDORSEMENT_CHOICES,
        default=ENDORSEMENT_DRAFT)
    endorsement_status_modified = models.DateTimeField(
        verbose_name="Endorsement Status Modified", editable=False, null=True)
    approval_status = models.PositiveSmallIntegerField(
        verbose_name="Approval Status", choices=APPROVAL_CHOICES,
        default=APPROVAL_DRAFT)
    approval_status_modified = models.DateTimeField(
        verbose_name="Approval Status Modified", editable=False, null=True)
    ignition_status = models.PositiveSmallIntegerField(
        verbose_name="Ignition Status",
        choices=IGNITION_STATUS_CHOICES, default=IGNITION_NOT_STARTED)
    ignition_status_modified = models.DateTimeField(
        verbose_name="Ignition Status Modified", editable=False, null=True)
    status = models.PositiveSmallIntegerField(
        choices=STATUS_CHOICES, default=STATUS_OPEN)
    status_modified = models.DateTimeField(
        verbose_name="Status Modified", editable=False, null=True)
    ignition_completed_date = models.DateField(
        blank=True, null=True, verbose_name="Ignition Completed")
    forest_blocks = models.TextField(
        verbose_name="Forest Blocks (if applicable)", blank=True)

    def __str__(self):
        return self.burn_id

    @property
    def description(self):
        located = "in %s" % self.tenure_text if self.tenure_text else ""
        blocks = "in %s" % self.forest_blocks if self.forest_blocks else ""
        return (
            "Prescribed burn %(burn_id)s is located %(located)s, "
            "%(location_text)s %(forest_blocks)s. The area of the burn is "
            "approximately %(area).1f hectares and consists primarily of "
            "%(veg_types)s. Year last burnt was %(last_burnt)s."
        ) % {
            'located': located,
            'location_text': self.location_text or "TBD",
            'forest_blocks': blocks,
            'veg_types': ", ".join(unicode(v) for v
                                   in self.vegetation_types.all()) or "TBD",
            'last_burnt': (self.last_season_object and
                           unicode(self.last_season_object) or "unknown"),
            'burn_id': self.burn_id,
            'area': self.area,
        }

    def save(self, **kwargs):
        """
        Automatically create the burn name on first save.
        """
        if not self.pk:
            count = Prescription.objects.filter(
                district=self.district,
                planned_season=self.planned_season,
                planned_year=self.planned_year).count() + 1
            self.burn_id = "%s_%03d" % (self.district.code, count)

        # Update ignition status to complete if ignition_completed_date
        if self.ignition_completed_date:
            self.ignition_status = self.IGNITION_COMPLETE
            self.ignition_status_modified = timezone.now()
        else:
            if self.areaachievement_set.all().count() > 0:
                self.ignition_status = self.IGNITION_COMMENCED
                self.ignition_status_modified = timezone.now()
            else:
                self.ignition_status = self.IGNITION_NOT_STARTED
                self.ignition_status_modified = timezone.now()

        super(Prescription, self).save(**kwargs)

    def get_absolute_url(self):
        return reverse('admin:prescription_prescription_detail',
                       args=(str(self.pk)))

    def clean_contentious(self):
        if self.contentious is None:
            raise ValidationError("You must select Yes or No for Contentious.")

    def clean_contentious_rationale(self):
        if self.contentious and not self.contentious_rationale:
            raise ValidationError("A contentious burn requires a contentious "
                                  "rationale.")

    def clean_last_year(self):
        if self.last_year and self.last_year > timezone.now().year:
            raise ValidationError("Last year burnt must not be in the future.")
        if self.last_year and self.last_year < 1900:
            raise ValidationError("Last year burnt must be after 1900.")

    def clean_planned_year(self):
        if self.planned_year and self.planned_year < timezone.now().year:
            raise ValidationError("Planned year burnt must be in the current "
                                  "year or in the future.")

    def clean_location(self):
        if ((self.location and
             len(self.location.split("Within the locality of ")))) == 1:
            location = self.location.split('|')
            if not (location[0] and location[1] and location[2] and
                    location[3]):
                raise ValidationError("You must enter/select a value in all "
                                      "fields. Alternatively, if entering "
                                      "only a locality, location will be "
                                      "stored as 'Within the locality of "
                                      "____'.")

    def clean(self):
        planned_season = self.planned_season_object
        if ((self.last_year and self.last_season and
             self.planned_year and self.planned_season and
             planned_season is not None and
             planned_season.start < self.last_season_object.start)):
            raise ValidationError("Last burnt season and year must be before "
                                  "planned burn season and year.")

        if self.last_year and self.last_year_unknown:
            raise ValidationError("Last year can not be set and marked "
                                  "unknown at the same time.")

        if self.last_season and self.last_season_unknown:
            raise ValidationError("Last season can not be set and marked "
                                  "unknown at the same time.")

    @property
    def treatments(self):
        return Treatment.objects.filter(register__prescription=self)

    # template tag or not needed :)
    @property
    def document_json(self):
        from pbs.document.models import DocumentCategory
        documents = OrderedDict()
        for cat in DocumentCategory.objects.all().order_by('order'):
            docs = []
            for item in self.document_set.filter(category=cat):
                docs.append(item.document.name.split("/")[-1])
            documents[cat.name] = docs
        return documents

    @property
    def evaluations(self):
        from pbs.report.models import Evaluation
        return Evaluation.objects.filter(criteria__prescription=self)

    @property
    def pre_burn_actions(self):
        return Action.objects.filter(risk__prescription=self, pre_burn=True)

    @property
    def day_of_burn_actions(self):
        return Action.objects.filter(risk__prescription=self, day_of_burn=True)

    @property
    def post_burn_actions(self):
        return Action.objects.filter(risk__prescription=self, post_burn=True)

    @property
    def tenure_text(self):
        if self.tenures.all().count() > 0:
            tenures = []
            for tenure in self.tenures.all():
                tenures.append(tenure.name)
            return ', '.join(tenures)
        else:
            return ''

    # The field or widget should be able to give us this value.
    # Possible refactor
    @property
    def location_text(self):
        if self.location:
            value = self.location.split('|')
            if len(value) > 1:
                return '{0} - {1}km(s) {2} of {3}'.format(
                    value[0] or '', (value[1] or ''), (value[2] or ''),
                    (value[3] or ''))
            else:
                return self.location
        return ''

    # Should have a template filter that does this already?
    def date_modified_local(self):
        local_zone = tz.tzlocal()
        return self.modified.astimezone(local_zone).strftime('%d/%m/%Y %H:%M:%S')

    @property
    def season(self):
        return "%s %d" % (self.get_planned_season_display(), self.planned_year)

    @property
    def last_year_burnt(self):
        if self.last_year_unknown:
            return "Unknown"
        else:
            return str(self.last_year)

    @property
    def last_season_burnt(self):
        if self.last_season_unknown:
            return "Unknown"
        else:
            return self.get_last_season_display()

    @property
    def planned_season_object(self):
        try:
            return Season.objects.get(name=self.planned_season,
                                      start__year=self.planned_year)
        except Season.DoesNotExist:
            pass

    @property
    def last_season_object(self):
        if self.last_season and self.last_year:
            return Season.objects.get(
                name=self.last_season, start__year=self.last_year)
        elif self.last_season_unknown:
            return "Unknown"

    @property
    def is_draft(self):
        """
        Return true if this ePFP is in draft status.
        """
        return self.endorsement_status == self.ENDORSEMENT_DRAFT

    @property
    def is_planned(self):
        """
        Return true if this ePFP has received planning approval from corporate
        executive.
        """
        return self.planning_status == self.PLANNING_APPROVED

    @property
    def is_endorsed(self):
        """
        Return true if this ePFP has been fully endorsed.
        """
        return self.endorsement_status == self.ENDORSEMENT_APPROVED

    @property
    def is_approved(self):
        """
        Return true if this ePFP has been approved.
        """
        return self.approval_status == self.APPROVAL_APPROVED

    @property
    def is_closed(self):
        return self.status == self.STATUS_CLOSED

    @property
    def is_burnt(self):
        return self.ignition_status == self.IGNITION_COMPLETE

    @property
    def has_ignitions(self):
        return self.ignition_status != self.IGNITION_NOT_STARTED

    @property
    def ignition_commenced(self):
        return self.areaachievement_set.latest()

    @property
    def has_corporate_approval(self):
        return self.planning_status == self.PLANNING_APPROVED

    @property
    def current_approval(self):
        return self.approval_set.latest()

    def clear_endorsements(self, commit=True):
        self.endorsement_set.all().delete()
        self.endorsement_status = self.ENDORSEMENT_DRAFT
        if commit:
            self.save()

    def clear_approvals(self):
        # cancel endorsements and approvals
        self.clear_endorsements(commit=False)
        self.approval_status = self.APPROVAL_DRAFT
        self.save()

    @property
    def can_corporate_approve(self):
        """
        Return true if this prescription can be submitted for corporate
        approval.
        """
        return (
            self.priority != Prescription.PRIORITY_UNSET and
            self.area != Decimal('0.0') and
            self.perimeter != Decimal('0.0') and
            self.location is not None and self.location != '' and
            (self.treatment_percentage != 0 and
             self.treatment_percentage is not None) and
            self.purposes.count() != 0 and self.allocation is not None and
            (self.last_season is not None or self.last_season_unknown) and
            (self.last_year is not None or self.last_year_unknown) and
            self.contentious is not None
        )

    @property
    def can_endorse(self):
        """
        Return true if this prescription can be submitted for endorsement.
        """
        return (self.planning_status == self.PLANNING_APPROVED and
                self.pre_state.finished and self.day_state.finished and
                self.endorsing_roles_determined)

    @property
    def can_edit_risk_register(self):
        """
        Return true if all of part A is complete (except Risk Register), all of
        part B, and post-burn actions of part C.
        Refer to BR-14.
        """
        return (self.pre_state.complete_except_risk and self.day_state.finished
                and self.post_state.post_actions)

    @property
    def can_select_endorsing_roles(self):
        """
        Return true if endorsing roles can be selected for this prescription.
        """
        return (self.is_draft and self.pre_state.complexity_analysis and
                self.pre_state.risk_register)

    @property
    def all_endorsed(self):
        """
        Determine if all needed endorsements have been endorsed.
        """
        return (self.endorsement_set.filter(endorsed=True).count() ==
                self.endorsing_roles.count())

    @property
    def all_reviewed(self):
        """
        Determine if all needed endorsements have been reviewed.
        """
        return self.not_endorsed_endorsing_roles.count() == 0

    @property
    def not_endorsed_endorsing_roles(self):
        # we take endoring roles for this prescription and exclude the ones
        # that has been endorsed
        return self.endorsing_roles.exclude(
            id__in=self.endorsement_set.values_list('role__id', flat=True))

    @property
    def can_approve(self):
        """
        Return true if this prescription can be submitted for approval.
        """
        return (self.can_endorse and
                self.endorsement_status == self.ENDORSEMENT_APPROVED)

    @property
    def can_epfp_approve(self):
        """
        Return true if this prescription can be submitted for epfp approval
        or extension.
        """

        return ((self.get_maximum_risk.final_risk_level !=
                 self.get_maximum_risk.LEVEL_VERY_HIGH) and
                # draft
                (self.can_approve and
                 self.approval_status == self.APPROVAL_DRAFT) or
                # submitted
                self.approval_status == self.APPROVAL_SUBMITTED or
                # extension
                (self.approval_status == self.APPROVAL_APPROVED and
                 self.current_approval and
                 self.current_approval.extension_count < 3))

    @property
    def can_ignite(self):
        """
        Return true if this burn plan can be acted upon and ignited.
        """
        return self.pre_state.finished and self.day_state.finished

    @property
    def can_close(self):
        """
        Return true if this burn plan can be closed.
        Refer to BR-50.
        """
        return (self.pre_state.finished and self.day_state.finished and
                self.post_state.post_burn_checklist and
                self.ignition_completed_date)

    @property
    def get_maximum_draft_risk(self):
        registers = self.register_set.annotate(Max('draft_risk_level'))
        if registers.count() > 0:
            return registers.latest('draft_risk_level__max')
        else:
            return None

    @property
    def maximum_draft_risk(self):
        """
        Determine the maximum draft risk of this burn plan.
        """
        if self.get_maximum_draft_risk:
            return self.get_maximum_draft_risk.get_draft_risk_level_display()
        else:
            return 'Very High'

    @property
    def maximum_draft_risk_html(self):
        maximum_draft_risk, label, role = self._max_risk(
            self.maximum_draft_risk)
        risk_level = ('<span id="id_max_risk" class="label {0}">{1}</span>'
                      .format(label, maximum_draft_risk))
        return mark_safe(risk_level)

    @property
    def get_maximum_risk(self):
        registers = self.register_set.annotate(Max('final_risk_level'))
        if registers.count() > 0:
            return registers.latest('final_risk_level__max')
        else:
            return None

    @property
    def maximum_risk(self):
        """
        Determine the maximum risk of this burn plan.
        """
        if self.get_maximum_risk:
            return self.get_maximum_risk.get_final_risk_level_display()
        else:
            return 'Very High'

    @property
    def maximum_risk_html(self):
        maximum_risk, label, role = self._max_risk(self.maximum_risk)
        risk_level = ('<span id="id_max_risk" class="label {0}">{1}</span>'
                      .format(label, maximum_risk))
        return mark_safe(risk_level)

    def _max_risk(self, maximum_risk):
        """
        Determine the maximum final/draft risk of this burn plan.
        Display as HTML span.
        """
        # the self.maximum_draft_risk is a property method that triggers TWO db
        # queries whenever this property is accessed
        # so the if statement below could cost up to 8 db queries!
        label = ''
        if maximum_risk == Register.LEVEL_CHOICES[
                Register.LEVEL_VERY_LOW - 1][1]:
            label = 'label-very-low'
            role = 'District Manager'
        elif maximum_risk == Register.LEVEL_CHOICES[
                Register.LEVEL_LOW - 1][1]:
            label = 'label-low'
            role = 'District Manager'
        elif maximum_risk == Register.LEVEL_CHOICES[
                Register.LEVEL_MEDIUM - 1][1]:
            label = 'label-medium'
            role = 'Regional Manager'
        elif maximum_risk == Register.LEVEL_CHOICES[
                Register.LEVEL_HIGH - 1][1]:
            label = 'label-high'
            role = 'Manager FMSB'
        else:
            label = 'label-very-high'
            role = 'Not available (the risk level is too high)'
        return maximum_risk, label, role

    @property
    def maximum_risk_role(self):
        maximum_risk, label, role = self._max_risk(self.maximum_risk)
        risk_role = ('<span id="id_risk_role" class="label {0}">{1}</span>'
                      .format(label, role))
        return mark_safe(risk_role)

    @property
    def get_maximum_complexity(self):
        return self.complexity_set.latest('rating')

    @property
    def maximum_complexity(self):
        """
        Determine the maximum complexity of this burn plan.
        """
        return self.get_maximum_complexity.get_rating_display()

    @property
    def total_edging_depth(self):
        from pbs.report.models import AreaAchievement
        return AreaAchievement.objects.filter(prescription=self).aggregate(Sum('edging_depth_estimate'))['edging_depth_estimate__sum']

    @property
    def total_edging_length(self):
        from pbs.report.models import AreaAchievement
        return AreaAchievement.objects.filter(prescription=self).aggregate(Sum('edging_length'))['edging_length__sum']

    @property
    def total_burnt_area_estimate(self):
        from pbs.report.models import AreaAchievement
        return AreaAchievement.objects.filter(prescription=self).aggregate(Sum('area_estimate'))['area_estimate__sum']

    @property
    def total_treatment_area(self):
        from pbs.report.models import AreaAchievement
        return AreaAchievement.objects.filter(prescription=self).aggregate(Sum('area_treated'))['area_treated__sum']

    @property
    def complexities(self):
        qs = self.complexity_set.all()
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]
        return qs

    @property
    def contingencies(self):
        qs = self.contingency_set.all()
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]
        return qs

    @property
    def priorities(self):
        # Relevant priorities
        qs = self.priorityjustification_set.filter(relevant=True)
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]
        return qs

    def _ways(self):
        if not hasattr(self, '_all_ways'):
            from pbs.prescription.templatetags import prescription_tags
            self._all_ways = prescription_tags.all_ways({'current': self})
        return self._all_ways
    ways = property(_ways)

    @property
    def context_statements(self):
        # Relevant context_statements
        qs = Context.objects.filter(prescription=self)
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]
        return qs

    @property
    def risk_registers(self):
        # Relevant Risk Register's
        qs = Register.objects.filter(prescription=self)
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]
        return qs

    @property
    def sectiona2_modified(self):
        # avoid circular import
        from pbs.stakeholder.models import CriticalStakeholder
        critical_stakeholders_modified = CriticalStakeholder.objects.filter(
            prescription=self).aggregate(Max('modified'))["modified__max"]
        context_map_modified = self.document_set.tag_names(
            "Context Map").aggregate(Max('modified'))["modified__max"]
        return max([modified for modified in
                    self.priorities.modified, self.context_statements.modified,
                    critical_stakeholders_modified, context_map_modified,
                    self.created
                    if modified is not None])

    def sectiona3_modified(self):
        objectives_modified = self.objective_set.aggregate(
            Max('modified'))["modified__max"]
        successcriteria_modified = self.successcriteria_set.aggregate(
            Max('modified'))["modified__max"]
        return max([modified for modified in
                    objectives_modified, successcriteria_modified,
                    self.created
                    if modified is not None])

    def sectionb5_modified(self):
        bp_modified = self.burningprescription_set.aggregate(
            Max('modified'))["modified__max"]
        ep_modified = self.edgingplan_set.aggregate(
            Max('modified'))["modified__max"]
        ls_modified = self.lightingsequence_set.aggregate(
            Max('modified'))["modified__max"]
        ea_modified = self.exclusionarea_set.aggregate(
            Max('modified'))["modified__max"]
        return max([modified for modified in
                    bp_modified, ep_modified,
                    ls_modified, ea_modified,
                    self.created
                    if modified is not None])

    class Meta:
        verbose_name = 'Prescribed Fire Plan'
        verbose_name_plural = 'Prescribed Fire Plans'
        permissions = (
            ("can_corporate_approve", "Can apply corporate approval"),
            ("can_delete_approval", "Can remove ePFP approval"),
        )


@python_2_unicode_compatible
class PriorityJustification(Audit):
    PRIORITY_UNRATED = 0
    PRIORITY_LOW = 1
    PRIORITY_MEDIUM = 2
    PRIORITY_HIGH = 3
    PRIORITY_CHOICES = (
        (PRIORITY_UNRATED, 'Unrated'),
        (PRIORITY_LOW, '1'),
        (PRIORITY_MEDIUM, '2'),
        (PRIORITY_HIGH, '3'),
    )

    prescription = models.ForeignKey(Prescription, null=True)
    purpose = models.ForeignKey(Purpose, verbose_name='Burn Purpose')
    order = models.PositiveSmallIntegerField(default=0)
    criteria = models.TextField(
        verbose_name="Prioritisation Criteria", blank=True)
    rationale = models.TextField(blank=True)
    priority = models.PositiveSmallIntegerField(
        choices=PRIORITY_CHOICES, default=PRIORITY_UNRATED)
    relevant = models.BooleanField(default=False)

    _required_fields = ('rationale', 'priority')

    def __str__(self):
        return self.purpose.name

    class Meta:
        verbose_name = "Burn Priority Justification"
        verbose_name_plural = "Burn Priority Justifications"
        unique_together = ('purpose', 'prescription')
        ordering = ['order']

    def clean_rationale(self):
        if self.priority and not self.rationale:
            raise ValidationError('Rationale must be set for this purpose as '
                                  'it has been given a priority.')

    def clean_priority(self):
        if self.rationale and self.priority == 0:
            raise ValidationError('Priority must be set for this purpose as '
                                  'it has been given a rationale.')


@python_2_unicode_compatible
class RegionalObjective(Audit):
    """
    """
    IMPACT_REGION = 1
    IMPACT_FMA = 2
    IMPACT_CHOICES = (
        (IMPACT_REGION, 'Region'),
        (IMPACT_FMA, 'Fire Management Area')
    )
    region = models.ForeignKey(Region)
    impact = models.PositiveSmallIntegerField(
        choices=IMPACT_CHOICES, default=IMPACT_REGION,
        help_text="Area of application for objective",
        verbose_name="scale of application")
    fma_names = models.TextField(
        help_text="If the impact of this objective is Fire Management Area, "
                  "enter the names of the areas of application here",
        verbose_name="Fire Management Areas", blank=True)
    objectives = models.TextField()

    _required_fields = ('region', 'impact', 'objectives')

    def __str__(self):
        return self.objectives[:64]

    class Meta:
        verbose_name = 'Regional Fire Management Plan Objective'
        verbose_name_plural = 'Regional Fire Management Plan Objectives'


@python_2_unicode_compatible
class Objective(Audit):
    """
    """
    objectives = models.TextField(help_text="Prescription Objectives")
    prescription = models.ForeignKey(
        Prescription, help_text="Prescription this objective belongs to")

    _required_fields = ('objectives', )

    def __str__(self):
        return self.objectives

    class Meta:
        verbose_name = "Burn Objective"
        verbose_name_plural = "Burn Objectives"
        ordering = ["created"]


@python_2_unicode_compatible
class SuccessCriteria(Audit):
    """
    """
    objectives = models.ManyToManyField(Objective)
    criteria = models.TextField(verbose_name="Success Criteria")
    prescription = models.ForeignKey(
        Prescription,
        help_text="Prescription this success criteria belongs to")

    _required_fields = ('criteria', )

    def __str__(self):
        return self.criteria

    class Meta:
        verbose_name = "Success Criteria"
        verbose_name_plural = "Success Criterias"
        ordering = ["created"]


@python_2_unicode_compatible
class SMEAC(models.Model):
    category = models.CharField(max_length=200)

    def __str__(self):
        return self.category


class DefaultBriefingChecklist(models.Model):
    smeac = models.ForeignKey(SMEAC, verbose_name="SMEAC")
    title = models.CharField(max_length=200)


@python_2_unicode_compatible
class BriefingChecklist(Audit):
    title = models.CharField(max_length=200, verbose_name="Topic")
    prescription = models.ForeignKey(Prescription)
    smeac = models.ForeignKey(SMEAC, verbose_name="SMEAC")
    action = models.ForeignKey('risk.Action', blank=True, null=True)
    notes = models.TextField(
        verbose_name="Briefing Notes", blank=True)

    class Meta:
        verbose_name = "Checklist Item"
        verbose_name_plural = "Checklist Items"
        ordering = ['smeac__id', 'id']

    def __str__(self):
        return '{0}|{1}'.format(self.smeac, truncatewords(self.title, 8))


@python_2_unicode_compatible
class Endorsement(Audit):
    ENDORSED_CHOICES = (
        (None, ''),
        (False, 'Reviewed and not endorsed'),
        (True, 'Endorsed'),
    )
    prescription = models.ForeignKey(Prescription)
    role = models.ForeignKey(EndorsingRole)
    endorsed = models.NullBooleanField(choices=ENDORSED_CHOICES, default=None)

    def __str__(self):
        if self.endorsed is not None:
            return "%s by %s" % (self.get_endorsed_display(),
                                 self.creator.get_full_name())
        else:
            return self.creator.get_full_name()


@python_2_unicode_compatible
class Approval(Audit):
    prescription = models.ForeignKey(Prescription)
    initial_valid_to = models.DateField(
        verbose_name="Valid To (Initial)", default=timezone.now,
        editable=False)
    # the valid_to.default is redefined in the form to refer to the last day
    # of this prescription's planned season
    valid_to = models.DateField(verbose_name="Valid To", default=timezone.now)
    extension_count = models.PositiveSmallIntegerField(
        verbose_name="Extension Count", default=0,
        validators=[MaxValueValidator(3)], editable=False)

    @property
    def next_valid_to(self):
        return self.valid_to + timedelta(days=14)

    def save(self, **kwargs):
        if not self.pk:
            self.initial_valid_to = self.valid_to
        super(Approval, self).save(**kwargs)

    def __str__(self):
        return "Approved by {0} until {1}".format(
            self.creator.get_full_name(), self.valid_to.strftime('%d/%b/%Y'))

    def clean_valid_to(self):
        if ((self.valid_to and
             self.valid_to > self.prescription.planned_season_object.end)):
            raise ValidationError("A burn cannot be approved with a valid "
                                  "date of later than the end of the planned "
                                  "season.")
        if ((self.valid_to and
             self.valid_to < self.prescription.planned_season_object.start)):
            raise ValidationError("A burn cannot be approved with a valid "
                                  "date of earlier than the start of the "
                                  "planned season.")

    class Meta:
        ordering = ["-id"]
        get_latest_by = "valid_to"


@receiver(post_save, sender=Prescription)
def create_risks(sender, instance, created, **kwargs):
    """
    For each standard risk, create a copy on the new prescription if the
    prescription has just been created.
    Also create complexities for this prescription.
    """
    if created:
        logger.debug("Creating standard risks for prescription %s" % instance)
        risks = []
        for risk in Risk.objects.filter(prescription=None, custom=False):
            risk.pk = None
            risk.prescription = instance
            risks.append(risk)
        Risk.objects.bulk_create(risks)
        risks = instance.risk_set.values("pk", "creator", "modifier")

        Action.objects.bulk_create(
            Action(creator_id=risk["creator"], modifier_id=risk["modifier"],
                   risk_id=risk["pk"]) for risk in risks)

        complexities = []
        for complexity in Complexity.objects.filter(prescription=None):
            complexity.pk = None
            complexity.prescription = instance
            complexities.append(complexity)
        Complexity.objects.bulk_create(complexities)

        for item in DefaultBriefingChecklist.objects.all():
            BriefingChecklist.objects.create(
                prescription=instance, smeac=item.smeac, title=item.title)

        items = []
        for item in PriorityJustification.objects.filter(prescription=None):
            item.pk = None
            item.prescription = instance
            items.append(item)
        PriorityJustification.objects.bulk_create(items)

        for category, display in Context.CATEGORY_CHOICES:
            Context.objects.create(prescription=instance,
                                   category=category)

        logger.info("Finished creating risks...")


@receiver(m2m_changed, sender=Prescription.purposes.through)
def update_justification(sender, instance, action, reverse, model, pk_set,
                         **kwargs):
    """
    When a user selects relevant burn purposes, change our priority
    justification page to reflect only the relevant purposes. The changelist
    has its queryset filtered on whether or not the justification is relevant.
    """
    if action == 'post_add':
        if pk_set is not None:
            logger.debug("Updating priority justifications...")
            qs = instance.priorityjustification_set
            qs.filter(purpose__in=pk_set).update(relevant=True)
            qs.filter(~Q(purpose__in=pk_set)).update(relevant=False)


@receiver(post_save, sender=Action)
def update_briefing_checklist_save(sender, instance, created, **kwargs):
    """
    Note: Does not delete/update any 'extra' BriefingChecklists because
    there is only one Briefing checklist for each category.
    """
    for field, category in instance.SMEAC_MAP:
        value = getattr(instance, field)
        smeac = SMEAC.objects.get(category__iexact=category)
        kwargs = {
            'prescription': instance.risk.prescription,
            'action': instance,
            'smeac': smeac
        }
        if value and instance.day_of_burn_include:
            if instance.details:
                title = "%s - %s" % (instance.risk, instance.details)
            else:
                title = instance.risk
            bc, created = BriefingChecklist.objects.get_or_create(**kwargs)
            bc.title = title
            bc.save()
        else:
            BriefingChecklist.objects.filter(**kwargs).delete()
