"""
Built-in, globally-available admin actions.
"""

from django.core.exceptions import PermissionDenied
from django.contrib import messages
from django.contrib.admin import helpers
from django.contrib.admin.util import model_ngettext
from django.db import router
from django.template.response import TemplateResponse
from django.utils.encoding import force_text
from django.utils.translation import ugettext_lazy, ugettext as _

from pbs.utils import get_deleted_objects


def delete_selected(modeladmin, request, queryset):
    """
    Default action which deletes the selected objects.

    This action first displays a confirmation page whichs shows all the
    deleteable objects, or, if the user has no permission one of the related
    childs (foreignkeys), a "permission denied" message.

    Next, it deletes all selected objects and redirects back to the change list.
    """
    opts = modeladmin.model._meta
    app_label = opts.app_label

    # Check that the user has delete permission for the actual model
    if not modeladmin.has_delete_permission(request):
        raise PermissionDenied

    using = router.db_for_write(modeladmin.model)

    # Populate deletable_objects, a data structure of all related objects that
    # will also be deleted.
    deletable_objects, perms_needed, protected = get_deleted_objects(
        queryset, opts, request.user, modeladmin.admin_site, using)

    # The user has already confirmed the deletion.
    # Do the deletion and return a None to display the change list view again.
    if request.POST.get('post'):
        if perms_needed:
            raise PermissionDenied
        n = queryset.count()
        if n:
            prescription_list = []
            for obj in queryset:
                if obj._meta.object_name == 'Prescription':
                    prescription_list.append(obj.burn_id + ' - ' + obj.name + ' (' + obj.season + ')')
                obj_display = force_text(obj)
                modeladmin.log_deletion(request, obj, obj_display)
            queryset.delete()
            if str(opts) == 'prescription.prescription':
                msg = ''
                for pfp in prescription_list:
                    msg += '<ul>' + pfp + '</ul>'
                modeladmin.message_user(request, _("Successfully deleted the following ePFPs:\n{0}").format(msg),
                                        messages.SUCCESS, extra_tags = "safe")
            else:
                modeladmin.message_user(request, _("Successfully deleted %(count)d %(items)s.") % {
                    "count": n, "items": model_ngettext(modeladmin.opts, n)
                }, messages.SUCCESS)
        # Return None to display the change list page again.
        return None

    if len(queryset) == 1:
        objects_name = force_text(opts.verbose_name)
    else:
        objects_name = force_text(opts.verbose_name_plural)

    if perms_needed or protected:
        title = _("Cannot delete %(name)s") % {"name": objects_name}
    else:
        title = _("Are you sure?")

    context = {
        "title": title,
        "objects_name": objects_name,
        "deletable_objects": [deletable_objects],
        'queryset': queryset,
        "perms_lacking": perms_needed,
        "protected": protected,
        "opts": opts,
        "app_label": app_label,
        'action_checkbox_name': helpers.ACTION_CHECKBOX_NAME,
    }

    # Display the confirmation page
    return TemplateResponse(request, modeladmin.delete_selected_confirmation_template or [
        "admin/%s/%s/delete_selected_confirmation.html" % (app_label, opts.module_name),
        "admin/%s/delete_selected_confirmation.html" % app_label,
        "admin/delete_selected_confirmation.html"
    ], context, current_app=modeladmin.admin_site.name)

delete_selected.short_description = ugettext_lazy("Delete selected %(verbose_name_plural)s")


def delete_approval_endorsement(modeladmin, request, queryset):
    opts = modeladmin.model._meta
    app_label = opts.app_label

    if (not request.user.has_perm('prescription.can_delete_approval')
        or not request.user.has_perm('prescription.can_delete_endorsement')):
        raise PermissionDenied

    if len(queryset) > 1:
        messages.error(request, _(
            "You can only remove approvals and endorsements "
            "from one ePFP at a time."))
        return None

    # The user has already confirmed the deletion.
    # Do the deletion and return a None to display the change list view again.
    if request.POST.get('post'):
        n = queryset.count()
        if n:
            map(lambda x: x.clear_approvals(), queryset)
            modeladmin.message_user(request, _(
                "Successfully removed endorsements and approval "
                "from %(pfp)s.") % {
                    "pfp": queryset[0].burn_id + ' - ' + queryset[0].name + ' (' + queryset[0].season + ')'},
                messages.SUCCESS)
        # Return None to display the change list page again.
        return None

    title = _("Are you sure?")

    context = {
        "title": title,
        "remove": 'all endorsements and approval',
        "action": 'delete_approval_endorsement',
        "objects_name": force_text(opts.verbose_name),
        'queryset': queryset,
        "opts": opts,
        "app_label": app_label,
        'action_checkbox_name': helpers.ACTION_CHECKBOX_NAME,
    }

    # Display the confirmation page
    return TemplateResponse(
        request, modeladmin.remove_selected_confirmation_template,
        context, current_app=modeladmin.admin_site.name)

delete_approval_endorsement.short_description = ugettext_lazy("Remove Burn Plan Endorsements and Approval")
