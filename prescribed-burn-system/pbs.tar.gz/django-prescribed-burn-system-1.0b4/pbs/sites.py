from __future__ import (unicode_literals, absolute_import)

from functools import update_wrapper

from django.conf import settings
from django.contrib.admin import ModelAdmin
from django.contrib.admin.validation import ImproperlyConfigured
from django.contrib.auth import REDIRECT_FIELD_NAME, login
from django.contrib.auth.models import User, Group
from django.contrib.auth.admin import UserAdmin as AuthUserAdmin, GroupAdmin
from django.contrib.sites.models import get_current_site
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect, HttpResponseForbidden
from django.shortcuts import resolve_url
from django.template import add_to_builtins
from django.template.response import TemplateResponse
from django.utils.http import is_safe_url
from django.utils.translation import ugettext as _
from django.views.decorators.cache import never_cache
from django.views.decorators.debug import sensitive_post_parameters
from django.utils.decorators import method_decorator

from pbs.document.admin import DocumentAdmin
from pbs.document.models import Document
from pbs.forms import UserForm, ProfileForm, PbsAdminAuthenticationForm
from pbs.implementation.admin import (BurningPrescriptionAdmin,
                                      EdgingPlanAdmin, LightingSequenceAdmin,
                                      ExclusionAreaAdmin, RoadSegmentAdmin,
                                      TrailSegmentAdmin, SignInspectionAdmin)
from pbs.implementation.models import (RoadSegment, TrailSegment,
                                       SignInspection, TrafficControlDiagram,
                                       BurningPrescription, EdgingPlan,
                                       LightingSequence, ExclusionArea)
from pbs.models import Profile
from pbs.prescription.admin import (PrescriptionAdmin, ObjectiveAdmin,
                                    RegionalObjectiveAdmin,
                                    SuccessCriteriaAdmin,
                                    PriorityJustificationAdmin,
                                    BriefingChecklistAdmin)
from pbs.prescription.models import (Prescription, RegionalObjective,
                                     Objective, PriorityJustification,
                                     SuccessCriteria, BriefingChecklist)
from pbs.report.admin import (AreaAchievementAdmin, ProposedActionAdmin,
                              EvaluationAdmin, PostBurnChecklistAdmin)
from pbs.report.models import (AreaAchievement, Evaluation, ProposedAction,
                               PostBurnChecklist)
from pbs.risk.admin import (RegisterAdmin, ContextAdmin, ComplexityAdmin,
                            ContingencyAdmin, ActionAdmin, TreatmentAdmin,
                            RiskAdmin, ContextRelevantActionAdmin)
from pbs.risk.models import (Risk, RiskCategory, Context, Action,
                             Register, Treatment, Contingency, Complexity,
                             ContextRelevantAction)
from pbs.stakeholder.admin import (CriticalStakeholderAdmin,
                                   PublicContactAdmin, NotificationAdmin)
from pbs.stakeholder.models import (CriticalStakeholder, PublicContact,
                                    Notification)

from swingers.sauth.sites import AuditSite


class UserAdmin(AuthUserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name',
                    'is_active')
    actions = None
    form = UserForm
    fieldsets = ((None, {'fields': ('username', 'email', ('first_name',
                                    'last_name'), 'is_active', 'groups')}),)
    list_filter = ("is_active", "groups")


class PrescriptionSite(AuditSite):
    def has_permission(self, request):
        return request.user.is_active

    def get_urls(self):
        """
        Add a view to clear the current prescription from the session
        """
        from django.conf.urls import patterns, url

        def wrap(view, cacheable=False):
            def wrapper(*args, **kwargs):
                return self.admin_view(view, cacheable)(*args, **kwargs)
            return update_wrapper(wrapper, view)

        urlpatterns = patterns(
            '',
            url(r'^administration/$',
                wrap(self.site_admin),
                name='site_admin'),
            url(r'^profile/$',
                wrap(self.profile),
                name='profile'),
        )

        return urlpatterns + super(PrescriptionSite, self).get_urls()

    def index(self, request):
        try:
            profile = request.user.profile
        except:
            profile = None

        url = reverse('admin:prescription_prescription_changelist')
        if profile is not None and profile.region:
            url += '?region=%s' % profile.region.id
        return HttpResponseRedirect(url)

    def password_change(self, request):
        if request.user.profile.is_fpc_user():
            return super(PrescriptionSite, self).password_change(request)
        else:
            return HttpResponseForbidden("You are not an FPC user. Only FPC "
                                         "users can change their password "
                                         "via this interface.")

    def register(self, model, admin_class=None, **options):
        try:
            super(PrescriptionSite, self).register(
                model, admin_class, **options)
        except ImproperlyConfigured:
            self._registry[model] = admin_class(model, self)

    @method_decorator(sensitive_post_parameters())
    @never_cache
    def login(self, request, redirect_field_name=REDIRECT_FIELD_NAME,
              authentication_form=PbsAdminAuthenticationForm,
              extra_context=None):
        """
        Displays the login form and handles the login action.
        """
        redirect_to = request.REQUEST.get(redirect_field_name, '')

        if request.method == 'POST':
            form = authentication_form(request, data=request.POST)
            if form.is_valid():

                # Ensure the user-originating redirection url is safe.
                if not is_safe_url(url=redirect_to, host=request.get_host()):
                    redirect_to = resolve_url(settings.LOGIN_REDIRECT_URL)

                # If this is the user's first login, redirect them to
                # edit their profile.
                user = form.get_user()
                if user.last_login == user.date_joined:
                    request.session['first_login'] = True
                    redirect_to = reverse('admin:profile')

                # Okay, security check complete. Log the user in.
                login(request, user)

                return HttpResponseRedirect(redirect_to)
        else:
            form = authentication_form(request)

        current_site = get_current_site(request)

        # We won't need this in Django 1.6
        request.session.set_test_cookie()

        context = {
            'title': _('Log in'),
            'app_path': request.get_full_path(),
            'form': form,
            redirect_field_name: request.get_full_path(),
            'site': current_site,
            'site_name': current_site.name,
        }
        if extra_context is not None:
            context.update(extra_context)
        return TemplateResponse(request,
                                self.login_template or 'admin/login.html',
                                context, current_app=self.name)

    @never_cache
    def logout(self, request, extra_context=None):
        from django.contrib.auth.views import logout
        return logout(request, reverse('admin:index', current_app=self.name))

    def site_admin(self, request, extra_context=None):
        context = {}
        context.update(extra_context or {})
        return TemplateResponse(request, "admin/site_admin.html", context,
                                current_app=self.name)

    def profile(self, request):
        profile = request.user.get_profile()
        if request.method == 'POST':
            form = ProfileForm(request.POST, instance=profile)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(reverse('admin:index',
                                                    current_app=self.name))
        else:
            form = ProfileForm(instance=profile)
        context = {
            'title': _('Edit profile'),
            'form': form
        }
        return TemplateResponse(request, "admin/profile.html", context,
                                current_app=self.name)


site = PrescriptionSite()

site.register(User, UserAdmin)
site.register(Group, GroupAdmin)

site.register(Prescription, PrescriptionAdmin)
site.register(RegionalObjective, RegionalObjectiveAdmin)
site.register(Objective, ObjectiveAdmin)
site.register(SuccessCriteria, SuccessCriteriaAdmin)
site.register(PriorityJustification, PriorityJustificationAdmin)

site.register(RiskCategory, ModelAdmin)
site.register(Register, RegisterAdmin)
site.register(Risk, RiskAdmin)
site.register(Treatment, TreatmentAdmin)
site.register(Context, ContextAdmin)
site.register(ContextRelevantAction, ContextRelevantActionAdmin)
site.register(CriticalStakeholder, CriticalStakeholderAdmin)
site.register(PublicContact, PublicContactAdmin)
site.register(Notification, NotificationAdmin)
site.register(Complexity, ComplexityAdmin)
site.register(Contingency, ContingencyAdmin)
site.register(Profile, ModelAdmin)
site.register(Action, ActionAdmin)
site.register(AreaAchievement, AreaAchievementAdmin)

site.register(RoadSegment, RoadSegmentAdmin)
site.register(TrailSegment, TrailSegmentAdmin)
site.register(SignInspection, SignInspectionAdmin)
site.register(BurningPrescription, BurningPrescriptionAdmin)
site.register(EdgingPlan, EdgingPlanAdmin)
site.register(LightingSequence, LightingSequenceAdmin)
site.register(BriefingChecklist, BriefingChecklistAdmin)
site.register(ExclusionArea, ExclusionAreaAdmin)
site.register(Document, DocumentAdmin)
site.register(TrafficControlDiagram, ModelAdmin)
site.register(ProposedAction, ProposedActionAdmin)
site.register(Evaluation, EvaluationAdmin)
site.register(PostBurnChecklist, PostBurnChecklistAdmin)


# add our own texify filter to the builtins here.
add_to_builtins('pbs.prescription.templatetags.texify')
