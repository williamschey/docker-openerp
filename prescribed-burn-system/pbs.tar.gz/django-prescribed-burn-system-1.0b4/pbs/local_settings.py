import os

# Database configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.contrib.gis.db.backends.postgis',
        'NAME': 'pbs_8204',
        'HOST': 'pgsql-001',
        'PORT': '5436',
        'USER': 'pbs',
        'PASSWORD': 'pbs',
    }
}

SECRET_KEY = '7e8964cebd5a2c8f3cb402337a05c8b5c92cd266c252bd8c1ca003c41a3443f4'

STATIC_ROOT = "/var/www/django_static/pbs_8204/"

"""
{{ project_name }}.ADMINS
{{ project_name }}.STATIC_ROOT
{{ project_name }}.HELP_URL

{{ project_name }}.LDAP_SERVER_URI
{{ project_name }}.LDAP_BIND_DN
{{ project_name }}.LDAP_BIND_PASSWORD
{{ project_name }}.LDAP_BASE
{{ project_name }}.LDAP_STAFF_FLAG
{{ project_name }}.LDAP_SUPERUSER_FLAG

{{ project_name }}.EMAIL_HOST
{{ project_name }}.EMAIL_PORT
"""
