from __future__ import (division, print_function, unicode_literals,
                        absolute_import)
import logging
logger = logging.getLogger("log." + __name__)

import os
import subprocess
from django.conf import settings
from django.forms import ValidationError
from django.utils import timezone
from django.utils.encoding import python_2_unicode_compatible
from django.template.defaultfilters import date
from django.core.validators import MinValueValidator, MaxValueValidator
from django.core.files.storage import FileSystemStorage
from django.utils.safestring import mark_safe

from swingers import models
from swingers.models import Audit

from pbs.prescription.models import Prescription, Season

trafficdiagram_storage = FileSystemStorage(
    location=os.path.join(settings.STATIC_ROOT, "pbs",
                          "traffic-control-diagrams"),
    base_url=settings.STATIC_URL + "pbs/traffic-control-diagrams/")


@python_2_unicode_compatible
class FuelType(Audit):
    name = models.CharField(
        verbose_name="Fuel Type", max_length=64, unique=True,
        help_text="Vegetation/Fuel Type")

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class IgnitionTypeManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


@python_2_unicode_compatible
class IgnitionType(models.Model):
    """
    """
    name = models.CharField(max_length=64, unique=True)
    objects = IgnitionTypeManager()

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name,)


class TrafficControlDiagramManager(models.Manager):
    def get_by_natural_key(self, name):
        return self.get(name=name)


@python_2_unicode_compatible
class TrafficControlDiagram(models.Model):
    """
    """
    name = models.CharField(max_length=64, unique=True)
    path = models.FileField(storage=trafficdiagram_storage, upload_to=".")
    objects = TrafficControlDiagramManager()

    @property
    def dimensions(self):
        width, height = subprocess.check_output([
            "identify", "-format", "%Wx%H,",
            self.document.path
        ]).split(",")[0].strip().split("x")
        return {"width": width, "height": height}

    @property
    def document(self):
        return self.path

    @property
    def descriptor(self):
        return self.name

    @property
    def modified(self):
        return False

    @property
    def filename(self):
        return os.path.basename(self.path.path)

    def __str__(self):
        return self.name

    def natural_key(self):
        return (self.name,)

    class Meta:
        ordering = ['id']
        verbose_name = "Traffic Control Diagram"
        verbose_name_plural = "Traffic Control Diagrams"


@python_2_unicode_compatible
class Way(Audit):
    prescription = models.ForeignKey(
        Prescription, help_text="Prescription this belongs to.")
    name = models.CharField(max_length=300)
    signs_installed = models.DateField(
        verbose_name="Signs Installed",
        null=True, blank=True)
    signs_removed = models.DateField(
        verbose_name="Signs Removed",
        null=True, blank=True)

    def __str__(self):
        return self.name

    def clean_signs_removed(self):
        if ((self.signs_removed and self.signs_installed and
             self.signs_removed < self.signs_installed)):
            raise ValidationError('Signs cannot be removed earlier than the '
                                  'install date.')


@python_2_unicode_compatible
class RoadSegment(Way):
    road_type = models.TextField(
        verbose_name="Road Type",
        blank=True)
    traffic_considerations = models.TextField(
        blank=True, verbose_name="Special Traffic Considerations")
    traffic_diagram = models.ForeignKey(
        TrafficControlDiagram, null=True, blank=True,
        verbose_name="Select Traffic Control Diagram")

    _required_fields = ('name', 'road_type',)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['id']
        verbose_name = "Road"
        verbose_name_plural = "Roads"


@python_2_unicode_compatible
class TrailSegment(Way):
    start = models.TextField(
        blank=True, verbose_name="Start Location")
    start_signage = models.TextField(
        blank=True, verbose_name="Description of Start Signage")
    stop = models.TextField(
        blank=True, verbose_name="Stop Location")
    stop_signage = models.TextField(
        blank=True, verbose_name="Description of Stop Signage")
    diversion = models.BooleanField(
        verbose_name="Is there a Diversion Map?", default=False)

    _required_fields = ('name', )

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['id']
        verbose_name = "Track/Trail"
        verbose_name_plural = "Tracks/Trails"


@python_2_unicode_compatible
class SignInspection(Audit):
    way = models.ForeignKey(
        Way, verbose_name="Road/Track/Trail Name")
    inspected = models.DateTimeField(
        default=timezone.now, verbose_name="Date Inspected")
    comments = models.TextField()
    inspector = models.TextField(verbose_name="Inspecting Officer")

    def __str__(self):
        return "%s (%s)" % (self.way.name, date(self.inspected))

    class Meta:
        ordering = ['id']
        verbose_name = "Sign Inspection"
        verbose_name_plural = "Sign Inspections"


@python_2_unicode_compatible
class BurningPrescription(Audit):
    prescription = models.ForeignKey(
        Prescription, help_text="Prescription this fuel schedule belongs to.")
    fuel_type = models.ForeignKey(
        FuelType,
        verbose_name="Fuel Type")
    scorch = models.PositiveIntegerField(
        help_text="Maximum Scorch Height (m)",
        verbose_name="Scorch Height",
        validators=[MinValueValidator(1), MaxValueValidator(30)],
        default=1)
    min_area = models.PositiveIntegerField(
        verbose_name="Min Area to be Burnt (%)",
        validators=[MinValueValidator(1), MaxValueValidator(100)],
        default=1)
    max_area = models.PositiveIntegerField(
        verbose_name="Max Area to be Burnt (%)",
        validators=[MinValueValidator(1), MaxValueValidator(100)],
        default=100)
    ros_min = models.PositiveIntegerField(
        verbose_name="Min ROS (m/h)",
        validators=[MinValueValidator(0), MaxValueValidator(10000)],
        default=0)
    ros_max = models.PositiveIntegerField(
        verbose_name="Max ROS (m/h)",
        validators=[MinValueValidator(0), MaxValueValidator(10000)],
        default=0)
    ffdi_min = models.PositiveIntegerField(
        verbose_name="Min FFDI",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    ffdi_max = models.PositiveIntegerField(
        verbose_name="Max FFDI",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    temp_min = models.PositiveIntegerField(
        verbose_name="Min Temp (degrees C)",
        validators=[MinValueValidator(0), MaxValueValidator(60)],
        default=0)
    temp_max = models.PositiveIntegerField(
        verbose_name="Max Temp (degress C)",
        validators=[MinValueValidator(0), MaxValueValidator(60)],
        default=0)
    rh_min = models.PositiveIntegerField(
        verbose_name="Min Relative Humidity (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    rh_max = models.PositiveIntegerField(
        verbose_name="Max Relative Humidity (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    glc_pct = models.PositiveIntegerField(
        verbose_name="Grassland Curing (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    sdi = models.TextField(verbose_name="SDI")
    smc_min = models.PositiveIntegerField(
        verbose_name="Min Surface Moisture Content (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    smc_max = models.PositiveIntegerField(
        verbose_name="Max Surface Moisture Content (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    pmc_min = models.PositiveIntegerField(
        verbose_name="Min Profile Moisture Content (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    pmc_max = models.PositiveIntegerField(
        verbose_name="Max Profile Moisture Content (%)",
        validators=[MinValueValidator(0), MaxValueValidator(100)],
        default=0)
    wind_min = models.PositiveIntegerField(
        verbose_name="Min Wind Speed (km/h)", default=0,
        validators=[MinValueValidator(0), MaxValueValidator(200)])
    wind_max = models.PositiveIntegerField(
        verbose_name="Max Wind Speed (km/h)",
        validators=[MinValueValidator(0), MaxValueValidator(200)],
        default=0)
    wind_dir = models.TextField(verbose_name="Wind Direction")

    def area(self):
        return "%d-%d" % (self.min_area, self.max_area)
    area.short_description = "Area to be Burnt (%)"

    def ros(self):
        return "%d-%d" % (self.ros_min, self.ros_max)
    ros.short_description = mark_safe(
        '<abbr title="Rate of Spread">ROS</abbr> Range')

    def ffdi(self):
        return "%d-%d" % (self.ffdi_min, self.ffdi_max)
    ffdi.short_description = mark_safe(
        '<abbr title="Forecast Fire Danger Index">FFDI</abbr> Range')

    def temp(self):
        return "%d-%d" % (self.temp_min, self.temp_max)
    temp.short_description = "Temperature Range"

    def rh(self):
        return "%d-%d" % (self.rh_min, self.rh_max)
    rh.short_description = mark_safe(
        '<abbr title="Relative Humidity">RH</abbr> Range (%)')

    sdi.short_description = mark_safe(
        '<abbr title="Soil Dryness Index">SDI</abbr> Range')

    def smc(self):
        return "%d-%d" % (self.smc_min, self.smc_max)
    smc.short_description = mark_safe(
        '<abbr title="Surface Moisture Content">SMC</abbr> Range')

    def pmc(self):
        return "%d-%d" % (self.pmc_min, self.pmc_max)
    pmc.short_description = mark_safe(
        '<abbr title="Profile Moisture Content">PMC</abbr> Range')

    def wind(self):
        return "%d-%d" % (self.wind_min, self.wind_max)
    wind.short_description = "Wind Speed Range (km/h)"

    def __str__(self):
        return self.fuel_type.name

    class Meta:
        verbose_name = "Burning Prescription"
        verbose_name_plural = "Burning Prescriptions"


@python_2_unicode_compatible
class EdgingPlan(Audit):
    prescription = models.ForeignKey(
        Prescription, help_text="Prescription this edging plan belongs to.")
    location = models.TextField(
        verbose_name="Edge Location",
        help_text="Textual description of edge & its location")
    desirable_season = models.PositiveSmallIntegerField(
        verbose_name="Desirable Season",
        max_length=64, choices=Season.SEASON_CHOICES)
    strategies = models.TextField(
        help_text="Textual description of strategies for this plan")
    fuel_type = models.ForeignKey(
        FuelType,
        verbose_name="Fuel Type",
        blank=True, null=True)
    ffdi_min = models.PositiveIntegerField(
        verbose_name="Min FFDI")
    ffdi_max = models.PositiveIntegerField(
        verbose_name="Max FFDI")
    sdi = models.TextField(verbose_name="SDI")
    wind_min = models.PositiveIntegerField(
        verbose_name="Min Wind Speed (km/h)")
    wind_max = models.PositiveIntegerField(
        verbose_name="Max Wind speed (km/h)")
    wind_dir = models.TextField(verbose_name="Wind Direction")
    ros_min = models.PositiveIntegerField(
        verbose_name="Min ROS (m/h)")
    ros_max = models.PositiveIntegerField(
        verbose_name="Max ROS (m/h)")

    def ffdi(self):
        return "%d-%d" % (self.ffdi_min, self.ffdi_max)
    ffdi.short_description = mark_safe(
        '<abbr title="Forecast Fire Danger Index">FFDI</abbr> Range')

    sdi.short_description = mark_safe(
        '<abbr title="Soil Dryness Index">SDI</abbr> Range')

    def wind(self):
        return "%d-%d" % (self.wind_min, self.wind_max)
    wind.short_description = "Wind Speed Range (km/h)"

    def __str__(self):
        return self.location

    class Meta:
        verbose_name = "Edging Plan"
        verbose_name_plural = "Edging Plans"


@python_2_unicode_compatible
class LightingSequence(Audit):
    prescription = models.ForeignKey(
        Prescription,
        help_text="Prescription this lighting sequence belongs to.")
    seqno = models.PositiveSmallIntegerField(
        verbose_name="Lighting Sequence Number",
        choices=Prescription.INT_CHOICES)
    cellname = models.CharField(verbose_name="Cell Name", max_length=64)
    strategies = models.TextField(
        help_text="Textual description of strategies for this sequence")
    wind_min = models.PositiveIntegerField(
        verbose_name="Min Wind Speed (km/h)",
        validators=[MinValueValidator(0), MaxValueValidator(200)],
        default=0)
    wind_max = models.PositiveIntegerField(
        verbose_name="Max Wind Speed (km/h)",
        validators=[MinValueValidator(0), MaxValueValidator(200)],
        default=0)
    wind_dir = models.TextField(verbose_name="Wind Direction")
    fuel_description = models.TextField(help_text="Fuel Description")
    fuel_age = models.PositiveSmallIntegerField(
        verbose_name="Fuel Age",
        help_text="Fuel Age in years",
        null=True, blank=True)
    fuel_age_unknown = models.BooleanField(
        verbose_name="Fuel Age Unknown?",
        default=False)
    ignition_types = models.ManyToManyField(
        IgnitionType, verbose_name="Planned Core Ignition Type")
    ffdi_min = models.PositiveIntegerField(
        verbose_name="FFDI Min", default=0)
    ffdi_max = models.PositiveIntegerField(
        verbose_name="FFDI Max", default=0)
    ros_min = models.PositiveIntegerField(
        verbose_name="ROS Min (m/h)", default=0)
    ros_max = models.PositiveIntegerField(
        verbose_name="ROS Max (m/h)", default=0)
    resources = models.TextField(
        verbose_name="Specialist Resources", blank=True)

    _required_fields = ('seqno', 'cellname', 'strategies',
                        'fuel_description', 'fuel_age', 'fuel_age_unknown',
                        'ignition_types', 'ffdi_min', 'ffdi_max',
                        'ros_min', 'ros_max', 'wind_min', 'wind_max',
                        'wind_dir')

    class Meta:
        verbose_name = "Lighting Sequence"
        verbose_name_plural = "Lighting Sequences"
        unique_together = (("prescription", "seqno"),)

    def wind_speed(self):
        return "%d-%d" % (self.wind_min, self.wind_max)
    wind_speed.short_description = mark_safe(
        '<abbr title="Wind Speed">Wind Speed</abbr> Range')

    def ffdi(self):
        return "%d-%d" % (self.ffdi_min, self.ffdi_max)
    ffdi.short_description = mark_safe(
        '<abbr title="Forecast Fire Danger Index">FFDI</abbr> Range')

    def ros(self):
        return "%d-%d" % (self.ros_min, self.ros_max)
    ros.short_description = mark_safe(
        '<abbr title="Rate of Spread">ROS</abbr> Range')

    def clean_fuel_age(self):
        if self.fuel_age_unknown and self.fuel_age:
                raise ValidationError(
                    'You must either enter a fuel age or tick Fuel Age ' +
                    'Unknown.')
        if not (self.fuel_age_unknown or self.fuel_age):
                raise ValidationError(
                    'You must enter a fuel age or tick Fuel Age Unknown.')

    def __str__(self):
        return "{0}. {1}".format(self.seqno, self.cellname)


@python_2_unicode_compatible
class ExclusionArea(Audit):
    prescription = models.ForeignKey(
        Prescription, help_text="Prescription this exclusion area belongs to.")
    description = models.TextField()
    location = models.TextField()
    detail = models.TextField(verbose_name="How will fire be excluded?")

    _required_fields = ('location', 'description',
                        'detail')

    def __str__(self):
        return "{0} - {1}".format(self.location, self.description)
