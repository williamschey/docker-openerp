from django import forms
from pbs.implementation.models import BurningPrescription, EdgingPlan
from pbs.forms import HelperModelForm, WideTextarea


class BurningPrescriptionForm(forms.ModelForm):

    class Meta:
        model = BurningPrescription
        fields = ('prescription', 'fuel_type', 'scorch', 'glc_pct')


class EdgingPlanForm(HelperModelForm):

    def __init__(self, *args, **kwargs):
        super(EdgingPlanForm, self).__init__(*args, **kwargs)
        self.fields['location'].widget = WideTextarea()
        self.fields['strategies'].widget = WideTextarea()

    class Meta:
        model = EdgingPlan
