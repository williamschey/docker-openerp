from django.contrib import admin
from django.template.defaultfilters import date, time
from django.utils.safestring import mark_safe

from pbs.admin import BaseAdmin
from pbs.implementation.forms import EdgingPlanForm
from pbs.prescription.admin import (PrescriptionMixin,
                                    SavePrescriptionMixin)

from chosen.widgets import ChosenSelectMultiple


class BurningPrescriptionAdmin(PrescriptionMixin, SavePrescriptionMixin,
                               admin.ModelAdmin):
    list_display = ("fuel_type", "scorch", "area", "ros", "ffdi", "temp",
                    "rh", "glc", "sdi", "smc", "pmc", "wind", "wind_dir")
    #form = BurningPrescriptionForm

    fieldsets = (
        (None, {
            "fields": ('fuel_type', 'scorch', ('min_area', 'max_area'),
                       ('ros_min', 'ros_max'), ('ffdi_min', 'ffdi_max'),
                       ('temp_min', 'temp_max'), ('rh_min', 'rh_max'),
                       'glc_pct', 'sdi', ('smc_min', 'smc_max'),
                       ('pmc_min', 'pmc_max'), ('wind_min', 'wind_max'),
                       'wind_dir')
        }),
    )

    def area(self, obj):
        return '{0}%'.format(obj.area())

    def rh(self, obj):
        return '{0}%'.format(obj.rh())

    def glc(self, obj):
        return '{0}%'.format(obj.glc_pct)

    actions = None


class EdgingPlanAdmin(PrescriptionMixin, SavePrescriptionMixin,
                      BaseAdmin):
    list_display = ("location", "desirable_season", "strategies", "fuel_type",
                    "ffdi", "sdi", "wind_dir", "wind", "ros")
    filter_horizontal = ("fuel_types", )
    list_empty_form = True
    list_display_links = ("location",)
    actions = None
    form = EdgingPlanForm

    fieldsets = (
        (None, {
            "fields": ('location', 'desirable_season', 'strategies',
                       'fuel_type', ('ffdi_min', 'ffdi_max'), 'sdi',
                       ('wind_min', 'wind_max'), 'wind_dir',
                       ('ros_min', 'ros_max'))
        }),
    )

    def ffdi(self, obj):
        return "%d-%d" % (obj.ffdi_min, obj.ffdi_max)
    ffdi.short_description = mark_safe('<abbr title="Forecast fire danger '
                                       'index">FFDI</abbr> range')

    def wind(self, obj):
        return "%d-%d" % (obj.wind_min, obj.wind_max)
    wind.short_description = "Wind speed range (km/h)"

    def ros(self, obj):
        return "{0}-{1}".format(obj.ros_min, obj.ros_max)
    ros.short_description = mark_safe('<abbr title="Rate of spread '
                                      '(m/h)">ROS</abbr> range')


class LightingSequenceAdmin(PrescriptionMixin, SavePrescriptionMixin,
                            BaseAdmin):
    list_display = ("seqno", "cellname", "strategies",
                    "fuel_description", "fuel_age",
                    "fuel_age_unknown", "ignition_types", "ffdi_min",
                    "ffdi_max", "ros_min", "ros_max",
                    "wind_min", "wind_max", "wind_dir", "resources")
    list_editable = ("seqno", "cellname", "strategies",
                     "fuel_description", "fuel_age",
                     "fuel_age_unknown", "ignition_types", "ffdi_min",
                     "ffdi_max", "ros_min", "ros_max",
                     "wind_min", "wind_max", "wind_dir", "resources")
    list_empty_form = True
    list_display_links = (None,)
    actions = None

    def formfield_for_manytomany(self, db_field, request=None, **kwargs):
        kwargs['widget'] = ChosenSelectMultiple()
        return super(LightingSequenceAdmin, self).formfield_for_manytomany(
            db_field, request, **kwargs)

    def ros(self, obj):
        return "%d-%d" % (obj.ros_min, obj.ros_max)
    ros.short_description = mark_safe('<abbr title="Rate of spread">ROS</abbr>'
                                      ' range')

    def ffdi(self, obj):
        return "%d-%d" % (obj.ffdi_min, obj.ffdi_max)
    ffdi.short_description = mark_safe('<abbr title="Forecast fire danger '
                                       'index">FFDI</abbr> range')


class ExclusionAreaAdmin(PrescriptionMixin, SavePrescriptionMixin,
                         BaseAdmin):
    list_display = ("location", "description", "detail")
    list_editable = ("location", "description", "detail")
    list_empty_form = True
    list_display_links = (None,)
    actions = None


class SignInspectionAdmin(PrescriptionMixin, SavePrescriptionMixin,
                          BaseAdmin):
    prescription_filter_field = "way__prescription"
    list_display = ("date_inspected", "way", "time_inspected", "comments",
                    "inspector")
    list_editable = ("way", "comments", "inspector")
    list_empty_form = True
    list_display_links = (None,)
    actions = None

    def date_inspected(self, obj):
        return date(obj.inspected)
    date_inspected.short_description = "Date Inspected"

    def time_inspected(self, obj):
        return time(obj.inspected)
    time_inspected.short_description = "Time of Inspection"


class RoadSegmentAdmin(PrescriptionMixin, SavePrescriptionMixin,
                       BaseAdmin):
    list_display = ("name", "road_type", "traffic_considerations",
                    "traffic_diagram", "signs_installed", "signs_removed")
    list_editable = ("name", "road_type", "traffic_considerations",
                     "traffic_diagram", "signs_installed", "signs_removed")
    list_empty_form = True
    list_display_links = (None,)
    actions = None

    def get_readonly_fields(self, request, obj=None):
        if self.prescription.is_draft:
            return self.readonly_fields
        else:
            return ("name", "road_type", "traffic_considerations",
                    "traffic_diagram")


class TrailSegmentAdmin(PrescriptionMixin, SavePrescriptionMixin,
                        BaseAdmin):
    list_display = ("name", "diversion", "start", "start_signage", "stop",
                    "stop_signage", "signs_installed", "signs_removed")
    list_editable = ("name", "diversion", "start", "start_signage",
                     "stop", "stop_signage", "signs_installed",
                     "signs_removed")
    list_empty_form = True
    list_display_links = (None,)
    actions = None

    def get_readonly_fields(self, request, obj=None):
        if self.prescription.is_draft:
            return self.readonly_fields
        else:
            return ("name", "diversion", "start", "start_signage",
                    "stop", "stop_signage")
