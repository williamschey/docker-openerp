from functools import partial

from django.contrib.admin import ModelAdmin, widgets
from django.forms.models import modelformset_factory

from pbs.forms import PbsModelForm

import logging
logger = logging.getLogger("log." + __name__)


class BaseAdmin(ModelAdmin):
    list_editable_extra = 0
    list_empty_form = False

    def get_list_editable(self, request):
        return self.list_editable

    def formfield_for_dbfield(self, db_field, **kwargs):
        # a quick patch to handle our "special" prescription-aware urls
        # disable the plus/add link (alias RelatedFieldWidgetWrapper)
        formfield = super(BaseAdmin, self).formfield_for_dbfield(db_field,
                                                                 **kwargs)
        if formfield and isinstance(formfield.widget,
                                    widgets.RelatedFieldWidgetWrapper):
            # bypass the wrapper, it quietly hides the "real" widget inside
            formfield.widget = formfield.widget.widget
        return formfield

    #def get_changelist_form(self, request, **kwargs):
    #    return self.get_form(self, request)

    def get_changelist_formset(self, request, **kwargs):
        """
        Returns a FormSet class for use on the changelist page if list_editable
        is used.
        """
        defaults = {
            "formfield_callback": partial(self.formfield_for_dbfield,
                                          request=request),
        }

        defaults.update(kwargs)
        fields = self.get_list_editable(request)
        return modelformset_factory(
            self.model, self.get_changelist_form(request, form=PbsModelForm),
            extra=self.list_editable_extra, fields=fields, **defaults)
