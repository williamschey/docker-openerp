from __future__ import unicode_literals, absolute_import

import re
from functools import update_wrapper

from django.contrib import admin
from django.contrib.admin.util import quote
from django.core.urlresolvers import reverse
from django.http import HttpResponseRedirect
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext as _
from django.utils.encoding import force_text

from pbs.document.models import DocumentTag, DocumentCategory
from pbs.document.forms import DocumentForm

from pbs.prescription.admin import (
    PrescriptionMixin, SavePrescriptionMixin)


class DocumentAdmin(PrescriptionMixin, SavePrescriptionMixin,
                    admin.ModelAdmin):
    list_display = ("descriptor_download", "category", "uploaded_on", "uploaded_by", "remove")
    list_display_links = (None,)
    fields = ("category", "tag", "custom_tag", "document")
    search_fields = ("category__name", "tag__name", "custom_tag", "modifier__username")
    actions = None
    form = DocumentForm

    def get_list_filter(self, request):
        if request.get_full_path().find("/tag/") == -1:
            return ("category", "modifier", "modified")
        else:
            return ()

    def uploaded_by(self, obj):
        return obj.modifier.get_full_name()
    uploaded_by.admin_order_field = "modifier"

    def uploaded_on(self, obj):
        return obj.modified
    uploaded_on.admin_order_field = "modified"

    def descriptor_download(self, obj):
        return mark_safe('<a href="{0}" target="_blank">'
                         '<i class="icon-file"></i> {1}'
                         '</a>'.format(obj.document.url, obj.descriptor))
    descriptor_download.admin_order_field = "tag"
    descriptor_download.short_description = "Descriptor"

    def response_post_save_add(self, request, obj):
        """
        Override the redirect url after successful save of a new document.
        """
        if request.session.get('previous_page', False):
            url = request.session.get('previous_page')
        else:
            url = reverse('admin:prescription_prescription_detail',
                          args=[str(obj.prescription.pk)])
        return HttpResponseRedirect(url)

    def response_post_save_change(self, request, obj):
        """
        Override the redirect url after successful save of an existing
        document.
        """
        if request.session.get('previous_page', False):
            url = request.session.get('previous_page')
        else:
            url = reverse('admin:prescription_prescription_detail',
                          args=[str(obj.prescription.pk)])
        return HttpResponseRedirect(url)

    def get_form(self, request, obj=None, **kwargs):
        previous_page = request.GET.get("next", False) or request.META.get('HTTP_REFERER')
        if (previous_page is not None and
                previous_page.split("/")[-4] not in ('add', 'change')):
            request.session['previous_page'] = previous_page

        return super(DocumentAdmin, self).get_form(request, obj=obj, **kwargs)

    def get_changelist(self, request, **kwargs):
        # Returns customised changelist filtered by tag or category as well as
        # current prescription
        ChangeList = super(DocumentAdmin, self).get_changelist(request, **kwargs)
        admin = self

        class DocumentChangeList(ChangeList):
            def get_query_set(self, request):
                qs = super(DocumentChangeList, self).get_query_set(request)
                current = admin.prescription

                if current:
                    fields = {
                        admin.prescription_filter_field: current
                    }
                    qs = qs.filter(**fields)

                category = re.findall("/category/(\d+)/", request.path)
                tag = re.findall("/tag/(\d+)/", request.path)

                if category:
                    qs = qs.filter(tag__category__id=int(category[0]))
                if tag:
                    qs = qs.filter(tag__id=int(tag[0]))

                return qs

        return DocumentChangeList

    def save_model(self, request, obj, form, change):
        obj.category = obj.tag.category
        super(DocumentAdmin, self).save_model(
            request=request, obj=obj, form=form, change=change)

    def add_view(self, request, prescription_id, form_url='', extra_context=None):
        model = self.model
        opts = model._meta
        tag = request.GET.get('tag')
        if tag is not None:
           self.exclude = ("custom_tag", "category")
           self.fields = ("tag", "document")
           dt = DocumentTag.objects.filter(id=int(tag))
           if dt.count():
               extra_context = extra_context or {}
               extra_context.update({
                   'title': (_('Add %s %s') %
                             (force_text(dt[0].name),
                              force_text(opts.verbose_name)))
               })
        return super(DocumentAdmin, self).add_view(request, prescription_id,
                                                   form_url, extra_context)

    def remove(self, obj):
        info = obj._meta.app_label, obj._meta.module_name
        delete_url = reverse('admin:%s_%s_delete' % info,
                             args=(quote(obj.pk), quote(self.prescription.pk)))
        tools = '''
            <a href="{0}" class="btn btn-mini alert-error"
            title="Delete" ><i class="icon-trash"></i></a>
        '''
        tools = tools.format(delete_url)

        return mark_safe(tools)
    remove.short_description = ""

    def get_urls(self):
        """
        Add some extra views for handling the prescription summaries and a page
        to handle selecting RFMP objectives for a burn.
        """
        from django.conf.urls import patterns, url

        def wrap(view):
            def wrapper(*args, **kwargs):
                return self.admin_site.admin_view(view)(*args, **kwargs)
            return update_wrapper(wrapper, view)

        info = self.model._meta.app_label, self.model._meta.module_name

        urlpatterns = [
            '',
            url(r'^prescription/(.+)/all/$',
                wrap(self.changelist_view),
                {"extra_context": {
                    "title": "Documents",
                    "tags": DocumentTag.objects.not_tag_names(
                        "Traffic Diagrams",
                        "Sign Inspection and Surveillance Form",
                        ("Prescribed Burning Organisational Structure "
                            "and Communications Plan"),
                        "Context Map", "Prescribed Burning SMEAC Checklist")
                }},
                name='%s_%s_all' % info)
        ]

        for category in DocumentCategory.objects.all():
            name = category.name.lower().replace(" ", "_")
            reverse = info + (name,)
            urlpatterns.append(
                url(r'^prescription/(.+)/category/%s/$' % category.pk,
                    wrap(self.changelist_view),
                    {"extra_context": {
                        "title": category.name,
                        "tags": category.documenttag_set.all()
                    }},
                    name='%s_%s_%s' % reverse)
            )

        for documenttag in DocumentTag.objects.all():
            name = documenttag.name.lower().replace(" ", "_")
            reverse = info + (name,)
            urlpatterns.append(
                url(r'^prescription/(.+)/tag/%s/$' % documenttag.pk,
                    wrap(self.changelist_view),
                    {"extra_context": {
                        "title": documenttag.name,
                        "tags": DocumentTag.objects.filter(id=documenttag.pk)
                    }},
                    name='%s_%s_%s' % reverse)
            )

        urlpatterns = patterns(*urlpatterns)

        return urlpatterns + super(DocumentAdmin, self).get_urls()
