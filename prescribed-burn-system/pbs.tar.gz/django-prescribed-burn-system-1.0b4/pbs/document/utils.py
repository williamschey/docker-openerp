from .models import DocumentTag


def document_tag_id_by_iname(name):
    return DocumentTag.objects.get(name__iexact=name).id
