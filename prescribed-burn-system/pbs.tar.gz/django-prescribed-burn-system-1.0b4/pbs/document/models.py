from __future__ import (division, print_function, unicode_literals,
                        absolute_import)
import logging
logger = logging.getLogger("log." + __name__)

import os
import subprocess
from io import BytesIO

from swingers.models import Audit
from swingers import models
from swingers.utils.decorators import workdir

from django.utils.encoding import python_2_unicode_compatible
from django.utils import timezone
from django.db.models import Max, FileField, Q
from django.forms import ValidationError
from django.template.defaultfilters import filesizeformat
from south.modelsinspector import add_introspection_rules
from smart_selects.db_fields import ChainedForeignKey

from pbs.prescription.models import Prescription


def content_file_name(self, filename):
    return "uploads/{0}/{0}_{1}_{2}_{3}.pdf".format(
        str(self.prescription.season).strip().replace(" ", "_"),
        self.prescription.burn_id,
        self.descriptor.strip().replace(" ", "_"),
        timezone.localtime(timezone.now()).isoformat(
        ).rsplit(".")[0].replace(":", "")[:-2])


class ContentTypeRestrictedFileField(FileField):
    '''Extend the Django FileField to specify:
    * content_types - list containing allowed MIME types for upload.
    * Example: ['application/pdf', 'image/jpeg']
    * max_upload_size - a number indicating the maximum file size
    *                   (bytes) allowed for upload.
    * Also convert to pdf
    '''
    def __init__(self, content_types=None, max_upload_size=None,
                 *args, **kwargs):
        self.content_types = content_types
        self.max_upload_size = max_upload_size
        super(ContentTypeRestrictedFileField, self).__init__(*args, **kwargs)

    @workdir()
    def clean(self, *args, **kwargs):
        data = super(
            ContentTypeRestrictedFileField, self).clean(*args, **kwargs)
        upload = data.file
        content_type = upload.content_type
        fname = os.path.basename(data.path)
        with open(fname, "w") as fin:
            fin.write(data.read())
        if content_type in self.content_types:
            if self.max_upload_size and upload._size > self.max_upload_size:
                raise ValidationError('Please ensure filesize is under %s. '
                                      'Current filesize: %s' % (
                                      filesizeformat(self.max_upload_size),
                                      filesizeformat(upload._size)))
            if fname.rsplit(".")[1] != "pdf":
                try:
                    pdfname = fname.rsplit(".")[0] + ".pdf"
                    subprocess.check_output(["convert", fname, pdfname])
                    fname = pdfname
                except subprocess.CalledProcessError:
                    raise ValidationError("File {0} appears to be corrupt, "
                                          "please check and try again." % (
                                              fname))
            try:
                subprocess.check_output(["pdfinfo", "-box", fname])
            except subprocess.CalledProcessError:
                raise ValidationError("File {0} appears to be corrupt, please "
                                      "check and try again.".format(fname))
            data.file = BytesIO(open(fname, "r").read())
            data.file.size = os.path.getsize(fname)
        else:
            # Generate list of OK file extensions.
            ext = [i.split('/')[1] for i in self.content_types]
            raise ValidationError('Filetype not supported (acceptable types: '
                                  '{0})'.format(', '.join(ext)))
        return data

add_introspection_rules(
    [], ["^pbs\.document\.models\.ContentTypeRestrictedFileField"])


@python_2_unicode_compatible
class DocumentCategory(models.Model):
    name = models.CharField(max_length=200)
    order = models.PositiveSmallIntegerField(default=0)

    class Meta:
        verbose_name = "Document Category"
        verbose_name_plural = "Document Categories"
        ordering = ['name']

    def __str__(self):
        return self.name


class CategoryManager(models.Manager):
    use_for_related_fields = True

    def _query_by_names(self, *names):
        return reduce(lambda x, y: x | y,
                      (Q(name__iexact=name) for name in names),
                      Q())

    def not_tag_names(self, *names):
        return self.get_query_set().exclude(self._query_by_names(*names))

    def tag_names(self, *names):
        return self.get_query_set().filter(self._query_by_names(*names))


@python_2_unicode_compatible
class DocumentTag(models.Model):
    name = models.CharField(
        verbose_name="Document Tag",
        max_length=200)
    category = models.ForeignKey(DocumentCategory)
    objects = CategoryManager()

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name


class TagManager(models.Manager):
    use_for_related_fields = True

    def partd(self):
        qs = self.not_tag_names("Traffic Diagrams",
                                "Sign Inspection and Surveillance Form",
                                ("Prescribed Burning Organisational Structure "
                                 "and Communications Plan"),
                                "Context Map",
                                "Prescribed Burning SMEAC Checklist")
        qs.modified = qs.aggregate(Max('modified'))["modified__max"]
        return qs

    def _query_by_names(self, *names):
        return reduce(lambda x, y: x | y,
                      (Q(tag__name__iexact=name) for name in names),
                      Q())

    def not_tag_names(self, *names):
        return self.get_query_set().exclude(self._query_by_names(*names))

    def tag_names(self, *names):
        return self.get_query_set().filter(self._query_by_names(*names))

    def __getattr__(self, name):
        if name[:4] == "tag_":
            qs = self.get_query_set().filter(
                tag__name__iexact=name[4:].replace("_", " "))
            qs.modified = qs.aggregate(Max('modified'))["modified__max"]
            return qs
        else:
            return super(TagManager, self).__getattr__(name)


@python_2_unicode_compatible
class Document(Audit):
    prescription = models.ForeignKey(
        Prescription, null=True,
        help_text="Prescription that this document belongs to")
    category = models.ForeignKey(DocumentCategory, related_name="documents")
    tag = ChainedForeignKey(
        DocumentTag, chained_field="category", chained_model_field="category",
        show_all=False, auto_choose=True, verbose_name="Descriptor")
    custom_tag = models.CharField(
        max_length=64, blank=True, verbose_name="Custom Descriptor")
    document = ContentTypeRestrictedFileField(
        upload_to=content_file_name,
        content_types=[
            'application/pdf', 'image/tiff', 'image/tif',
            'image/jpeg', 'image/jpg',
            'image/gif', 'image/png'],
        max_length=200,
        help_text='Acceptable file types: pdf, tiff, jpg, gif, png')

    objects = TagManager()

    @property
    def descriptor(self):
        if self.custom_tag:
            return "Other ({0})".format(self.custom_tag)
        else:
            return self.tag.name

    @property
    def dimensions(self):
        width, height = subprocess.check_output([
            "identify", "-format", "%Wx%H,",
            self.document.path
        ]).split(",")[0].strip().split("x")
        return {"width": width, "height": height}

    @property
    def filename(self):
        return os.path.basename(self.document.path)

    class Meta:
        ordering = ['tag', 'document']

    def __str__(self):
        return "{0} - {1}".format(self.prescription, self.document.name)
