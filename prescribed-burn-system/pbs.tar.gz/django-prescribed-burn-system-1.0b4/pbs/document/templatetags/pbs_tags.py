from django import template


from pbs.document.utils import document_tag_id_by_iname

register = template.Library()


@register.filter
def tag_id(name):
    """Returns a tag id for the given tag name, the lookup is
    case-insensitive
    """
    return document_tag_id_by_iname(name)


@register.assignment_tag
def filter_by_tag_name(qs, name):
    """Filters the queryset by tag name, the lookup is case-insensitive"""
    return qs.tag_names(name)


@register.inclusion_tag('admin/document_list.html', takes_context=True)
def document_list(context):
    """Created for Action report on the CAR screens."""
    current = context.get('current')
    request = context.get('request')
    if 'pre_burn' in request.GET:
        document_set = current.document_set.tag_names('Pre Burn Actions List')
        document_type = 'Pre Burn Actions Lists'
    elif 'day_of_burn' in request.GET:
        document_set = current.document_set.tag_names(
            'Day of Burn Actions List')
        document_type = 'Day of Burn Actions Lists'
    elif 'post_burn' in request.GET:
        document_set = current.document_set.tag_names('Post Burn Actions List')
        document_type = 'Post Burn Actions Lists'
    else:
        document_set = current.document_set.all()
        document_type = 'All documents'

    return {
        "current": current,
        "request": request,
        "document_type": document_type,
        "document_set": document_set
    }
