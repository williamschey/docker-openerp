from pbs.admin import BaseAdmin
from pbs.prescription.admin import PrescriptionMixin, SavePrescriptionMixin


class CriticalStakeholderAdmin(PrescriptionMixin, SavePrescriptionMixin,
                               BaseAdmin):
    list_display = ('name', 'organisation', 'interest')
    list_editable = ('name', 'organisation', 'interest')
    list_empty_form = True
    list_display_links = (None,)
    actions = None


class PublicContactAdmin(PrescriptionMixin, SavePrescriptionMixin,
                         BaseAdmin):
    list_display = ('modified', 'name', 'organisation', 'person', 'comments')
    list_editable = ('name', 'organisation', 'person', 'comments')
    list_empty_form = True
    list_display_links = (None,)
    actions = None


class NotificationAdmin(PrescriptionMixin, SavePrescriptionMixin, BaseAdmin):
    list_display = ('notified', 'contacted', 'organisation', 'address',
                    'phone')
    list_editable = ('notified', 'contacted', 'organisation', 'address',
                     'phone')
    list_empty_form = True
    list_display_links = (None,)
    actions = None
