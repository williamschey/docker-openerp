from django import forms

from pbs.risk.models import Risk, Treatment


class RiskForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(RiskForm, self).__init__(*args, **kwargs)
        if (kwargs.get('initial') is not None and
                kwargs['initial'].get('prescription') is not None):
            self.fields['prescription'].widget = forms.HiddenInput()
            self.fields['prescription'].help_text = ''

    class Meta:
        model = Risk
        exclude = ('custom', 'risk', )
        fields = ('prescription', 'category', 'name', )


class TreatmentForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super(TreatmentForm, self).__init__(*args, **kwargs)
        if (kwargs.get('initial') is not None and
                kwargs['initial'].get('register') is not None):
            # hide the tag choice list if the tag is preselected
            self.fields['register'].widget = forms.HiddenInput()
            self.fields['complete'].widget = forms.HiddenInput()

    class Meta:
        model = Treatment
