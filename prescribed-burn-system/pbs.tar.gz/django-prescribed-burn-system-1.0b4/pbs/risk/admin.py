from __future__ import unicode_literals
from functools import update_wrapper

from django.contrib import admin
from django.contrib.admin import SimpleListFilter
from django.contrib.admin.util import unquote, quote
from django.core.urlresolvers import reverse
from django.http import HttpResponse, HttpResponseRedirect
from django.utils.translation import ugettext_lazy as _

from pbs.admin import BaseAdmin
from pbs.prescription.admin import PrescriptionMixin, SavePrescriptionMixin
from pbs.prescription.templatetags.prescription_tags import risk_display
from pbs.risk.forms import RiskForm, TreatmentForm
from pbs.risk.models import Action, ContextRelevantAction

import json
from chosen.widgets import ChosenSelectMultiple


class RiskRegisterFilter(SimpleListFilter):
    """
    An annoying hack to get around not being able to pass custom GET
    variables around on a changelist. They get passed to filters and
    break the changelist if no filter classes are found to handle the
    variable.
    """
    title = _('section')
    parameter_name = 'section'

    def lookups(self, request, model_admin):
        return (
            ('draft', _('Initial risk assessment')),
            ('final', _('Treatments & final risk assessment')),
        )

    def queryset(self, request, queryset):
        return queryset


class RegisterAdmin(PrescriptionMixin, SavePrescriptionMixin,
                    BaseAdmin):
    prescription_filter_field = "prescription"
    list_editable = ("description", "draft_consequence",
                     "draft_likelihood", "alarp", "final_consequence",
                     "final_likelihood")
    list_per_page = 150
    list_display_links = (None, )
    list_filter = (RiskRegisterFilter,)
    list_empty_form = True
    actions = None

    def queryset(self, request):
        qs = super(RegisterAdmin, self).queryset(request)
        return qs.prefetch_related("treatment_set")

    def get_list_display(self, request):
        section = request.GET.get("section", "draft")
        if section == 'draft':
            return ("description",
                    "draft_consequence", "draft_likelihood",
                    "changelist_draft_risk_level", "alarp")
        elif section == "final":
            return ("description", "all_treatments",
                    "final_consequence", "final_likelihood",
                    "changelist_final_risk_level")
        return super(RegisterAdmin, self).get_list_display(request)

    def get_list_editable(self, request):
        """
        Only allow editing certain fields on the different pages.
        """
        section = request.GET.get("section", "draft")
        if section == 'draft':
            return ("description", "draft_consequence",
                    "draft_likelihood", "alarp")
        elif section == "final":
            return ("final_consequence", "final_likelihood")
        return super(RegisterAdmin, self).get_list_editable(request)

    def get_readonly_fields(self, request, obj):
        """
        If the ePFP has not had all part A (except risk register) complete, all
        of part B complete and post-burn actions of part C complete, do not
        allow the user to edit any risk register items.

        Similarly, if a PSoR has been marked ALARP, don't allow the user to
        edit the final likelihood or final consequences.
        """
        current = self.prescription
        if not current.can_corporate_approve:
            return self.list_editable
        else:
            return super(RegisterAdmin, self).get_readonly_fields(request, obj)

    def get_changelist_formset(self, request, **kwargs):
        FormSet = super(RegisterAdmin, self).get_changelist_formset(request)

        section = request.GET.get("section", "draft")
        if section == 'draft':
            class DraftFormSet(FormSet):
                def clean(self):
                    if any(self.errors):
                        return
            return DraftFormSet
        else:
            return FormSet

    def get_changelist_form(self, request, **kwargs):
        """
        If a PSoR has been marked ALARP, don't allow the user to
        edit the final likelihood or final consequences.
        """
        Form = super(RegisterAdmin, self).get_changelist_form(request,
                                                              **kwargs)
        section = request.GET.get("section", "draft")
        if section.lower() == "final":
            # custom processing for the ALARP-set fields -
            # lock the final_consequence and final_likelihood
            class FinalForm(Form):
                def __init__(self, *args, **kwargs):
                    super(FinalForm, self).__init__(*args, **kwargs)
                    if (kwargs.get('instance') is not None and
                            kwargs['instance'].alarp):
                        # there might be some cleaner way to do this, somehow
                        # hack this forms' Metaclass creation???
                        self.fields.pop('final_consequence', None)
                        self.fields.pop('final_likelihood', None)

            return FinalForm
        else:
            return Form

    def all_treatments(self, obj):
        if obj.treatment_set.count() > 0:
            output = '<ul>'
            for treatment in obj.treatment_set.all():
                if treatment.complete:
                    status_class = ' class="text-success"'
                    status_icon = '<i class="icon-ok"></i> '
                else:
                    status_class = ''
                    status_icon = ''

                treatment_url = reverse('admin:risk_treatment_change',
                                        args=(quote(treatment.pk),
                                              quote(self.prescription.pk)))
                output += '<a href="%s"><li%s>%s%s (%s)</li></a>' % (
                    treatment_url, status_class, status_icon,
                    treatment.description, treatment.location)
            output += '</ul>'
        else:
            if obj.alarp:
                output = 'No treatments required'
            else:
                output = 'No treatments'

        if not obj.alarp and not self.prescription.is_approved:
            url = reverse('admin:risk_treatment_add',
                          args=(quote(self.prescription.pk),),
                          current_app=self.admin_site.name)
            url += '?register=%d' % obj.pk
            output += (
                '<br><a id="add_treatment_%(pk)s" '
                'onclick="return showAddAnotherPopup(this);" '
                'class="add-another" href="%(url)s">'
                '<i class="icon-plus"></i> Add a treatment</a>'
            ) % {
                'pk': obj.pk,
                'url': url,
            }
        return output
    all_treatments.short_description = "Treatments"
    all_treatments.allow_tags = True

    def changelist_final_risk_level(self, obj):
        """
        Callable to display final_risk_level using colour based styling
        """
        return risk_display(obj)
    changelist_final_risk_level.short_description = 'Final ePFP Risk Level'
    changelist_final_risk_level.admin_order_field = 'final_risk_level'
    changelist_final_risk_level.required = True

    def changelist_draft_risk_level(self, obj):
        """
        Callable to display draft_risk_level using colour based styling
        """
        return risk_display(obj, draft=True)
    changelist_draft_risk_level.short_description = 'Draft ePFP Risk Level'
    changelist_draft_risk_level.admin_order_field = 'draft_risk_level'
    changelist_draft_risk_level.required = True


class ContextPestleFilter(SimpleListFilter):
    title = _('PESTLE')
    parameter_name = 'pestle'

    def lookups(self, request, model_admin):
        return (
            ('p', _('Political')),
            ('e', _('Economic')),
            ('s', _('Social')),
            ('t', _('Technical')),
            ('l', _('Legal')),
            ('en', _('Environmental')),
        )

    def queryset(self, request, queryset):
        if self.value() == 'p':
            return queryset.filter(categories__name='Political')
        elif self.value() == 'e':
            return queryset.filter(categories__name='Economic')
        elif self.value() == 's':
            return queryset.filter(categories__name='Social')
        elif self.value() == 't':
            return queryset.filter(categories__name='Technical')
        elif self.value() == 'l':
            return queryset.filter(categories__name='Legal')
        elif self.value() == 'en':
            return queryset.filter(categories__name='Environmental')


class ContextAdmin(PrescriptionMixin, SavePrescriptionMixin,
                   BaseAdmin):
    list_display = ("category", "statement")
    list_display_links = (None,)
    list_editable = ("statement",)
    list_empty_form = True
    actions = None

    def get_readonly_fields(self, request, obj=None):
        """
        If the ePFP can not yet be submitted for corporate approval,
        do not allow the user to edit any contexts.
        """
        current = self.prescription
        if not (current.is_draft or current.can_corporate_approve):
            return self.list_editable
        return super(ContextAdmin, self).get_readonly_fields(request, obj)

    def changelist_view(self, request, prescription_id, extra_context=None):
        context = extra_context or {}
        context.update({'relevant_actions':
                        ContextRelevantAction.objects.filter(
                        action__risk__prescription__id=unquote(
                            prescription_id)).select_related(
                                'action', 'action__risk')})
        return super(ContextAdmin, self).changelist_view(request,
                                                         prescription_id,
                                                         context)


class ContextRelevantActionAdmin(PrescriptionMixin, SavePrescriptionMixin,
                                 BaseAdmin):
    def change_view(self, request, object_id, *args, **kwargs):
        obj = self.get_object(request, unquote(object_id))

        if (obj is None or not self.has_change_permission(request, obj) or
                not request.is_ajax() or request.method != "POST"):
            return super(ContextRelevantActionAdmin, self).change_view(
                request, object_id, *args, **kwargs)
        else:
            ModelForm = self.get_form(request, obj, exclude=('action',))
            form = ModelForm(request.POST, request.FILES, instance=obj)
            considered = obj.considered     # form.is_valid() updates the obj
            if form.is_valid():
                obj = self.save_form(request, form, change=True)
                self.save_model(request, obj, form, change=True)
            else:
                obj.considered = considered
            return HttpResponse(json.dumps({'considered': obj.considered}))


class ComplexityAdmin(PrescriptionMixin, SavePrescriptionMixin,
                      admin.ModelAdmin):
    list_display = ("sub_factor", "rating", "rationale")
    list_display_links = ("sub_factor",)
    list_editable = ("rating", "rationale")
    list_filter = ("factor",)
    list_group_by = "factor"
    list_display_links = (None,)
    actions = None


class ContingencyAdmin(PrescriptionMixin, SavePrescriptionMixin,
                       BaseAdmin):
    list_display = ("description", "trigger", "action", "notify_name",
                    "organisation", "location", "contact_number")
    list_editable = ("description", "trigger", "action", "notify_name",
                     "organisation", "location", "contact_number")
    list_empty_form = True
    list_display_links = (None,)
    actions = None


class ActionAdmin(PrescriptionMixin, SavePrescriptionMixin,
                  BaseAdmin):
    actions = None
    list_per_page = 150
    prescription_filter_field = "risk__prescription"
    list_group_by = 'risk_category'
    list_display_links = (None,)
    list_editable = ("relevant", "pre_burn", "day_of_burn", "post_burn",
                     "context_statement", "details",
                     "pre_burn_resolved", "pre_burn_explanation",
                     "pre_burn_completed", "pre_burn_completer",
                     "day_of_burn_situation", "day_of_burn_mission",
                     "day_of_burn_execution", "day_of_burn_administration",
                     "day_of_burn_command", "day_of_burn_completed",
                     "day_of_burn_completer", "post_burn_completed",
                     "post_burn_completer", "day_of_burn_include")
    fieldsets = (
        (None, {
            "fields": ('risk', 'details', 'pre_burn',
                       'day_of_burn', 'post_burn', 'context_statement'),
        }),
    )

    def queryset(self, request):
        qs = super(ActionAdmin, self).queryset(request)
        return qs.select_related("risk", "risk__category")

    def lookup_allowed(self, key, value):
        if key in ('relevant__exact', 'risk__category__id__exact'):
            return True
        return super(ActionAdmin, self).lookup_allowed(key, value)

    def get_list_display(self, request):
        epfp_approved = self.prescription.is_approved
        if request.GET.get('pre_burn', False):
            pre_burn_list_display = (
                "__str__", "details", "pre_burn_resolved",
                "pre_burn_explanation")
            if epfp_approved:
                pre_burn_list_display += ("pre_burn_completed",
                                          "pre_burn_completer")
            return pre_burn_list_display
        elif request.GET.get('day_of_burn', False):
            day_of_burn_list_display = (
                "__str__", "details", "day_of_burn_include",
                "day_of_burn_situation", "day_of_burn_mission",
                "day_of_burn_execution", "day_of_burn_administration",
                "day_of_burn_command")
            if epfp_approved:
                day_of_burn_list_display += ("day_of_burn_completed",
                                             "day_of_burn_completer")
            return day_of_burn_list_display
        elif request.GET.get('post_burn', False):
            post_burn_list_display = ("__str__", "details")
            if epfp_approved:
                post_burn_list_display += ("post_burn_completed",
                                           "post_burn_completer")
            return post_burn_list_display
        else:
            current = self.prescription
            if ((current is not None and
                 current.endorsement_status != current.ENDORSEMENT_DRAFT)):
                return ("relevant", "__str__", "details",
                        "pre_burn", "day_of_burn", "post_burn",
                        "context_statement")
            else:
                return ("relevant", "__str__", "details",
                        "pre_burn", "day_of_burn", "post_burn",
                        "context_statement", "add_action")

    def get_list_editable(self, request):
        epfp_approved = self.prescription.is_approved
        if request.GET.get('pre_burn', False):
            pre_burn_list_editable = ("pre_burn_resolved",
                                      "pre_burn_explanation")
            if epfp_approved:
                pre_burn_list_editable += ("pre_burn_completed",
                                           "pre_burn_completer")
            return pre_burn_list_editable
        elif request.GET.get('day_of_burn', False):
            day_of_burn_list_editable = (
                "day_of_burn_include", "day_of_burn_situation",
                "day_of_burn_mission", "day_of_burn_execution",
                "day_of_burn_administration", "day_of_burn_command")
            if epfp_approved:
                day_of_burn_list_editable += ("day_of_burn_completed",
                                              "day_of_burn_completer")
            return day_of_burn_list_editable
        elif request.GET.get('post_burn', False):
            post_burn_list_editable = ()
            if epfp_approved:
                post_burn_list_editable += ("post_burn_completed",
                                            "post_burn_completer")
            return post_burn_list_editable
        else:
            return ("relevant", "details", "pre_burn", "day_of_burn",
                    "post_burn", "context_statement")

    def get_readonly_fields(self, request, obj=None):
        """
        If the ePFP can not yet be submitted for corporate approval,
        do not allow the user to edit any contexts.
        """
        actions = ['pre_burn', 'day_of_burn', 'post_burn']

        current = self.prescription
        if current is not None and not current.can_corporate_approve:
            return self.list_editable

        if any([request.GET.get(action, False) for action in actions]):
            return ("details",)

        return super(ActionAdmin, self).get_readonly_fields(request, obj)

    def get_list_filter(self, request):
        if request.GET.get("pre_burn", False):
            return None
        elif request.GET.get("day_of_burn", False):
            return None
        elif request.GET.get("post_burn", False):
            return None
        else:
            return ('relevant', 'risk__category')

    def risk_category(self, obj):
        return obj.risk.category

    def add_action(self, obj):
        if obj.index == 1:
            url = reverse('admin:risk_action_add',
                          args=(self.prescription.pk,),
                          current_app=self.admin_site.name)
            return ('<a class="btn btn-mini btn-success" href="%s?risk=%s">'
                    'Add</a>') % (url, obj.risk.pk)
        else:
            url = reverse('admin:risk_action_delete',
                          args=(obj.pk, self.prescription.pk),
                          current_app=self.admin_site.name)
            return ('<a class="btn btn-mini btn-danger" href="%s">'
                    'Remove</a>') % url
    add_action.short_description = "Multiple?"
    add_action.allow_tags = True


class TreatmentAdmin(PrescriptionMixin, BaseAdmin):
    prescription_filter_field = "register__prescription"
    list_display = ('description', 'location', 'complete')
    list_editable = ('description', 'location')
    form = TreatmentForm

    def get_urls(self):
        """
        Add an extra view to handle marking a treatment as complete.
        """
        from django.conf.urls import patterns, url

        def wrap(view):
            def wrapper(*args, **kwargs):
                return self.admin_site.admin_view(view)(*args, **kwargs)
            return update_wrapper(wrapper, view)

        info = self.model._meta.app_label, self.model._meta.module_name

        urlpatterns = patterns(
            '',
            url(r'^complete/$',
                wrap(self.mark_as_complete),
                name='%s_%s_complete' % info),
        )
        return urlpatterns + super(TreatmentAdmin, self).get_urls()

    def mark_as_complete(self, request):
        """Mark a treatment as "dealt with"."""
        object_id = request.POST.get('id')
        obj = self.get_object(request, unquote(object_id))
        if (obj is not None and self.has_change_permission(request, obj) and
                request.method == "POST"):
            ModelForm = self.get_form(request, obj, fields=('complete',))
            form = ModelForm(request.POST, request.FILES, instance=obj)
            complete = obj.complete     # form.is_valid() updates the obj
            if form.is_valid():
                obj = self.save_form(request, form, change=True)
                self.save_model(request, obj, form, change=True)
            else:
                obj.complete = complete
            return HttpResponse(json.dumps({'complete': obj.complete}))
        return HttpResponse(
            'Sorry, this endpoint only accepts valid POST requests.')

    def response_post_save_add(self, request, obj):
        """
        Override the redirect url after successful save of a new Treatment.
        """
        if request.session.get('previous_page', False):
            url = request.session.get('previous_page')
        else:
            url = reverse('admin:prescription_prescription_detail',
                          args=[str(obj.prescription.pk)])
        return HttpResponseRedirect(url)

    def response_post_save_change(self, request, obj):
        """
        Override the redirect url after successful save of an existing
        Treatment.
        """
        if request.session.get('previous_page', False):
            url = request.session.get('previous_page')
        else:
            url = reverse('admin:prescription_prescription_detail',
                          args=[str(obj.prescription.pk)])
        return HttpResponseRedirect(url)

    def get_form(self, request, obj=None, **kwargs):
        previous_page = request.GET.get("next", False)
        if not previous_page:
            previous_page = request.META.get('HTTP_REFERER')
        if ((previous_page is not None and
             previous_page.split("/")[-4] not in ('add', 'change') and
             previous_page.split("/")[-5] not in ('treatment'))):
            request.session['previous_page'] = previous_page
        if obj:  # obj is not None, so this is a change page
            kwargs['exclude'] = ['register', ]
        return super(TreatmentAdmin, self).get_form(request, obj=obj, **kwargs)


class RiskAdmin(PrescriptionMixin, BaseAdmin):
    form = RiskForm

    def save_model(self, request, obj, form, change):
        super(RiskAdmin, self).save_model(request, obj, form, change)
        if not change:
            Action.objects.create(risk=obj)
