*pbs* is <TODO>.

All documentation is in the "docs" directory and online at
http://dpaw.bitbucket.org/pbs/.

To **install** *pbs*: ::

    pip install pbs

or ::

    easy_install pbs

To get more **help**:

* Join the *dpaw* mailing list, or read the archives, at
  http://groups.google.com/group/dpaw.

To create a **ticket**:

* Use our bitbucket **issue tracker**, at
  https://bitbucket.org/dpaw/pbs/issues/

To **contribute** to *pbs*: ::

    hg clone https://bitbucket.org/dpaw/pbs/
    python setup.py develop

* We prefer patches submitted via pull requests, at
  https://bitbucket.org/dpaw/pbs/pull-requests/

To run *pbs*' **test** suite: ::

    python setup.py test


.. _Department of Parks and Wildlife: http://dpaw.wa.gov.au/
